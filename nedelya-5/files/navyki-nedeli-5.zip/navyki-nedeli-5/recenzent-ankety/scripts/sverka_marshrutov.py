#!/usr/bin/env python3
"""Тест маршрутов: анкета в платформе собрана так же, как в спецификации?

  python3 sverka_marshrutov.py vygruzka-testovyh.csv 01_карта-данных.md marshruty.csv [--id response_id]

marshruty.csv — по строке на тестовое прохождение (составляется по логике показа ДО прохождения):
  marshrut,response_id,dolzhny,ne_dolzhny
  1 пользуется и платит сам,10001,"Q2 Q3 Q4 Q5 Q6 Q7 OA1 M1 M2 M3 OA2 K1 K2","M4 L1"
  2 бросил,10002,"OA2 L1 K1 K2","Q2 Q3 Q4 Q5 Q6 Q7 OA1 M1 M2 M3 M4"
  dolzhny / ne_dolzhny — номера вопросов из карты через пробел: какие должны быть показаны и какие нет.
  Вопросы, которые по карте показаны всем, проверяются в каждом маршруте сами.

Проверяет: все колонки карты есть в выгрузке и лишних нет; коды ответов есть в карте; у каждого маршрута
ответы есть ровно у тех вопросов, которые должны были показаться. Карту под выгрузку не подгоняет:
не сошлось — это вопрос к сборке анкеты в платформе или к спецификации. Код выхода 2 при расхождениях.
"""
import sys, argparse
import pandas as pd
from karta import load, read_export


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('vygruzka'); ap.add_argument('karta'); ap.add_argument('marshruty'); ap.add_argument('--id', default='response_id')
    a = ap.parse_args()
    items = {it['id']: it for it in load(a.karta)}
    df = read_export(a.vygruzka)
    df[a.id] = df[a.id].astype(str).str.removesuffix('.0')
    R = pd.read_csv(a.marshruty, dtype=str).fillna('')
    bad = []
    if R.empty: sys.exit('ОСТАНОВКА: список маршрутов пуст; проверка не выполнена')
    cols_map = [c for it in items.values() for c in it['cols']]
    miss = [c for c in cols_map if c not in df.columns]; extra = [c for c in df.columns if c not in cols_map]
    if miss: bad.append(f'колонок карты нет в выгрузке: {", ".join(miss)}')
    if extra: bad.append(f'в выгрузке колонки не из карты: {", ".join(extra)}')
    for it in items.values():
        if it['codes'] and it['type'] in ('single', 'scale', 'scale010', 'split'):
            for c in it['cols']:
                if c in df.columns:
                    v = pd.to_numeric(df[c], errors='coerce')
                    out = df[c].notna() & ~v.isin(list(it['codes']))
                    if out.any():
                        bad.append(f'{c}: коды {sorted(set(df.loc[out, c].astype(str)))} не из карты')

    def answered(row, q):
        it = items.get(q)
        if not it:
            bad.append(f'вопроса {q} нет в карте'); return None
        vals = [row[c] for c in it['cols'] if c in row.index]
        return any(pd.notna(v) and str(v).strip() != '' for v in vals)

    print('Маршрут · что не так')
    for _, r in R.iterrows():
        rows = df[df[a.id] == str(r['response_id']).strip()]
        if rows.empty:
            bad.append(f"маршрут «{r['marshrut']}»: анкеты {r['response_id']} нет в выгрузке"); continue
        row = rows.iloc[0]
        vsem = [q for q, it in items.items() if it['base'] is None and it['type'] not in ('service', 'open', 'text')]
        for q in sorted(set(r['dolzhny'].split()) | set(vsem)):
            if answered(row, q) is False:
                bad.append(f"маршрут «{r['marshrut']}»: {q} должен был показаться — ответа нет")
        for q in r['ne_dolzhny'].split():
            if answered(row, q) is True:
                bad.append(f"маршрут «{r['marshrut']}»: {q} не должен был показаться — ответ есть")
    covered = {q for _, r in R.iterrows() for q in (r['dolzhny'] + ' ' + r['ne_dolzhny']).split()}
    shown_somewhere = {q for _, r in R.iterrows() for q in r['dolzhny'].split()}
    nocover = [q for q, it in items.items() if it['type'] not in ('service',) and it['base'] is not None and q not in shown_somewhere]
    if nocover:
        bad.append(f'Вопросы, которые не показались ни в одном маршруте: {", ".join(nocover)} — добавьте маршрут')
    for b in bad:
        print('  ' + b)
    if not bad:
        print('  Расхождений нет: каждый маршрут показал ровно то, что в спецификации, коды совпадают с картой.')
    sys.exit(2 if bad else 0)


if __name__ == '__main__':
    main()
