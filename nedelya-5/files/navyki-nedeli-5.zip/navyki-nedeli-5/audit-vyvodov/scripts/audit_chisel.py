#!/usr/bin/env python3
"""Аудит чисел: каждое число из текста выводов должно найтись в таблицах. Программа ищет, человек решает.

  python3 audit_chisel.py otchet.md tables/*.xlsx tables/*.csv [--dopusk 0.05]

Из текста берутся проценты, п.п., интервалы, n = …, суммы и баллы — с предложением, где они стоят.
Из таблиц — все числа из всех ячеек, включая числа внутри текста ячеек («[−17,2; −11,6]»).
Число из текста считается найденным, если в таблицах есть то же значение с тем же округлением
(41% найдётся по 40,96 или по 0,4096). Проверяются числа с %, п.п., ₽, дробной частью, после «n =» и в интервалах;
годы, номера пунктов, слайдов и вопросов (Q3, ИВ2, «18–29») не проверяются.
У найденного числа печатается, где оно нашлось: файл · лист · строка. «Найдено» ещё не «верно»:
проверяющий смотрит, та ли это строка, — 15% могли найтись в другом вопросе.
Второй раздел — слова, которые надо сверить с вердиктом по таблице «слово — условие».
Код выхода 2, если есть ненайденные числа.
"""
import re, sys, argparse, pathlib
import pandas as pd

NUM = re.compile(r'(?<![\w.,])([−\-+]?\d{1,3}(?:[  ]\d{3})+|[−\-+]?\d+(?:[.,]\d+)?)(?![\w])')
SLOVA = {
    'больше|меньше|чаще|реже|выше|ниже|лидирует|опережает|уступает': 'только если вердикт «разница есть» после поправки',
    'одинаков|не отличает|так же|столько же|на одном уровне': 'отсутствие обнаруженной разницы не доказывает равенства; нужна отдельная обоснованная проверка',
    'большинство|почти все|подавляющ': 'только если нижняя граница интервала выше 50%',
    'потому что|из-за|влияет|приводит к|благодаря': 'только для сплита или эксперимента; иначе «связано с»',
    'россиян|пользовател|люди считают|все хотят': 'для онлайн-панели — «опрошенные»',
    'оформят|купят|перейдут|будут платить|заплатят': 'намерение — не поведение: «хотели бы оформить», «говорят, что…»',
    'растёт|растет|снижается|тренд|динамик': 'только если есть две волны с той же анкетой',
    'заметно|значимо|существенно|резко|сильно': 'проверить: слово не сильнее вердикта и размера эффекта',
}


def to_f(s):
    s = s.replace('−', '-').replace(' ', '').replace(' ', '').replace(',', '.')
    try:
        return float(s)
    except ValueError:
        return None


KEYS = ('вопрос', 'текст', 'вариант', 'метрика', 'а', 'б', 'код', 'название', 'правило', 'группа')


def _ctx(row, head=None):
    if head is not None:
        t = [f'{row[i]}' for i, h in enumerate(head) if str(h).strip().lower() in KEYS and isinstance(row[i], str) and row[i].strip()]
        if t:
            return ' · '.join(x[:45] for x in t[:5])
    t = [str(v) for v in row if isinstance(v, str) and v.strip() and not NUM.fullmatch(v.strip())]
    return ' · '.join(x[:40] for x in t[:3])


def table_numbers(paths):
    """Все числа из таблиц с местом: (значение, «файл · лист · строка»). Шапка таблицы — первая строка."""
    vals = []
    for p in paths:
        p = pathlib.Path(p)
        if not p.exists():
            print(f'  нет файла {p} — пропускаю (маска без совпадений?)')
            continue
        if p.suffix.lower() in ('.xlsx', '.xls', '.csv'):
            sheets = pd.read_excel(p, sheet_name=None, header=None) if p.suffix.lower() != '.csv' else {'': pd.read_csv(p, header=None, dtype=str)}
            for sh, df in sheets.items():
                head = list(df.iloc[0]) if len(df) else None
                for row in df.values[1:]:
                    c = ' · '.join(x for x in (p.name, str(sh), _ctx(list(row), head)) if x)
                    vals += [(f, c) for v in row for f in _cell(v)]
        else:
            for line in p.read_text(encoding='utf-8').splitlines():
                for m in NUM.finditer(line):
                    f = to_f(m.group(1))
                    if f is not None:
                        vals.append((f, f'{p.name} · {line.strip()[:60]}'))
    return vals


def _cell(v):
    if v is None or (isinstance(v, float) and v != v):
        return []
    if isinstance(v, (int, float)):
        return [float(v)]
    return [f for f in (to_f(m.group(1)) for m in NUM.finditer(str(v))) if f is not None]


def stems(t):
    return {w[:5].lower() for w in re.findall(r'[A-Za-zА-Яа-яЁё]{5,}', t)}


def found(x, dec, vals, dop):
    tol = max(0.5 * 10 ** (-dec), dop) + 1e-9
    out = []
    for v, ctx in vals:
        if any(abs(c - x) <= tol for c in (v, v * 100)):
            if ctx not in out:
                out.append(ctx)
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('tekst'); ap.add_argument('tablicy', nargs='+'); ap.add_argument('--dopusk', type=float, default=0.0)
    a = ap.parse_args()
    text = pathlib.Path(a.tekst).read_text(encoding='utf-8')
    vals = table_numbers(a.tablicy)
    print(f'Чисел в таблицах: {len(vals)}')
    sents = re.split(r'(?<=[.!?])\s+|\n+', re.sub(r'п\.\s?п\.', 'п.п', text))   # «п.п.» — не конец предложения
    miss, hits, total = [], [], 0
    for s in sents:
        clean = re.sub(r'\b(?:[A-ZА-Я]{1,3}\d+(?:_\d+)?|ИВ\d+|слайд\w*\s+\d+)\b', ' ', s)
        clean = re.sub(r'\b\d{1,2}\s*[–-]\s*\d{1,2}\s*(?:лет|года)?\b', ' ', clean)   # возрастные группы 18–29
        clean = re.sub(r'\b(19|20)\d{2}\b', ' ', clean)                                 # годы
        clean = re.sub(r'^\s*\d+[.)]\s', ' ', clean)                                   # номер пункта списка
        for m in NUM.finditer(clean):
            raw = m.group(1)
            x = to_f(raw)
            if x is None:
                continue
            after, before = clean[m.end():m.end() + 6], clean[max(0, m.start() - 8):m.start()]
            vazhnoe = (re.search(r'[.,]\d', raw) or re.match(r'\s*(%|п\.\s?п\.|₽|руб|балл|пункт)', after)
                       or re.search(r'(n\s*=\s*|\[|;\s*|против\s*)$', before))
            if not vazhnoe:
                continue                                     # «3 вопроса», «2 волны» — не числа отчёта
            dec = len(re.split(r'[.,]', raw)[1]) if re.search(r'[.,]', raw) else 0
            total += 1
            where = found(x, dec, vals, a.dopusk)
            if not where:
                miss.append((raw, s.strip()))
            else:
                st = stems(s)
                where.sort(key=lambda c: -len(st & stems(c)))
                chuzhaya = not (st & stems(where[0]))
                hits.append((raw, s.strip(), where, chuzhaya))
    print(f'Чисел в тексте: {total}; не найдено в таблицах: {len(miss)}')
    for raw, s in miss:
        print(f'  «{raw}» — {s[:160]}')
    sus = [h for h in hits if h[3]]
    print(f'\nНайдено только в строках, где нет ни одного слова из предложения: {len(sus)} — проверьте первыми:')
    for raw, s, where, _ in sus:
        print(f'  ⚠ «{raw}» → ' + ' | '.join(where[:3]) + f'   ⟵ {s[:90]}')
    print('\nОстальные найденные числа — лучшее совпадение по словам первым (проверьте, та ли строка):')
    for raw, s, where, ch in hits:
        if ch:
            continue
        more = f' и ещё в {len(where) - 2}' if len(where) > 2 else ''
        print(f'  «{raw}» → ' + ' | '.join(where[:2]) + more + f'   ⟵ {s[:70]}')
    ver = []
    for p in a.tablicy:
        p = pathlib.Path(p)
        if p.exists() and p.suffix.lower() in ('.xlsx', '.xls'):
            for sh, df in pd.read_excel(p, sheet_name=None).items():
                if 'вердикт' in df.columns:
                    name = next((c for c in df.columns if c in ('метрика', 'название', 'код')), df.columns[0])
                    ns = [c for c in df.columns if str(c).endswith(': n')]
                    for _, r in df.iterrows():
                        ver.append(f"  {p.name} · {r[name]}" + (f" · {r.get('А', '')} против {r.get('Б', '')}" if 'А' in df.columns else '') +
                                   (' · n = ' + ' и '.join(str(r[c]) for c in ns) if ns else '') + f" → {r['вердикт']}")
    if ver:
        print('\nВердикты из таблиц сравнений — слово в тексте не сильнее этого:')
        print('\n'.join(ver))
    print('\nСлова, которые сверяются с вердиктом (таблица «слово — условие»):')
    k = 0
    for pat, rule in SLOVA.items():
        for s in sents:
            for m in re.finditer(rf'\b(?:{pat})\w*', s, re.I):
                k += 1
                print(f'  «{m.group(0)}» — {rule}: {s.strip()[:140]}')
    if not k:
        print('  нет')
    print('\nЧисло не найдено — не значит, что оно неверно: оно могло быть пересчитано в тексте. Но тогда пересчёт должен лежать в таблице.')
    sys.exit(2 if miss else 0)


if __name__ == '__main__':
    main()
