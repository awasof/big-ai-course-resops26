#!/usr/bin/env python3
"""Приём выгрузки: как прочиталась, сходится ли с картой данных и какие ловушки в ней есть.
Ничего не меняет и не чистит — только печатает, что нашёл. Решения о чистке — по правилам паспорта.

  python3 priem.py выгрузка.csv 01_карта-данных.md [--json отчёт.json]

Печатает: строки, колонки, заполненность; колонки, которых нет в карте и наоборот; по каждому вопросу —
коды вне карты, числа текстом, пустые ответы у тех, кому вопрос показан, ответы у тех, кому не показан;
кандидатов на чистку — тестовые анкеты, повторы номера участника, одинаковые анкеты, слишком быстрые,
одинаковые ответы подряд; частые ответы в «Другом». У каждой находки — число строк и номера нескольких анкет.
"""
import sys, json, argparse, re
import pandas as pd
from karta import load, read_export, shown
from chisla import to_number


def ids(df, mask, idcol, k=5):
    v = df.loc[mask, idcol].head(k).tolist() if idcol else df.index[mask][:k].tolist()
    return ', '.join(str(int(x)) if isinstance(x, float) and x == int(x) else str(x) for x in v)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('vygruzka'); ap.add_argument('karta'); ap.add_argument('--json')
    a = ap.parse_args()
    items = load(a.karta)
    df = read_export(a.vygruzka)
    rep = {'строк': len(df), 'колонок': df.shape[1], 'находки': []}
    idcol = next((it['cols'][0] for it in items if it['type'] == 'service' and re.search(r'id|номер ответа', it['cols'][0] + it['q'], re.I)), None)
    print(f'== Как прочиталось\nстрок {len(df)}, колонок {df.shape[1]}; номер анкеты — {idcol or "не нашёл, буду показывать номера строк"}')
    print(df.head(5).to_string(max_cols=12, max_colwidth=18))
    fill = df.notna().mean().mul(100).round(0)
    print('\n== Заполненность колонок, %')
    print(', '.join(f'{c} {int(v)}' for c, v in fill.items()))

    cols_map = [c for it in items for c in it['cols']]
    miss = [c for c in cols_map if c not in df.columns]
    extra = [c for c in df.columns if c not in cols_map]
    print('\n== Сверка с картой данных')
    print('Колонки карты, которых нет в выгрузке:', ', '.join(miss) or 'нет')
    print('Колонки выгрузки, которых нет в карте:', ', '.join(extra) or 'нет')
    rep['нет в выгрузке'], rep['нет в карте'] = miss, extra

    def note(kind, q, n, mask=None, extra=''):
        ex = ids(df, mask, idcol) if mask is not None else ''
        rep['находки'].append({'вопрос': q, 'что': kind, 'строк': int(n), 'примеры': ex, 'пояснение': extra})
        print(f'  {q}: {kind} — {n}' + (f' (например {ex})' if ex else '') + (f'; {extra}' if extra else ''))

    print('\n== Вопросы')
    for it in items:
        cols = [c for c in it['cols'] if c in df.columns]
        if not cols or it['type'] == 'service':
            continue
        try:
            sh = shown(df, it)
        except Exception as e:
            print(f"  {it['id']}: условие показа «{it['base_text']}» не считается: {e}")
            continue
        for c in cols:
            s = df[c]
            if it['type'] == 'number':
                conv = s.map(to_number)
                txt = conv.map(lambda t: t[1] == 'текст → число')
                bad = conv.map(lambda t: t[1] == 'не число')
                if txt.any():
                    note('число записано текстом', c, txt.sum(), txt, 'перевести в число по правилу из паспорта')
                if bad.any():
                    vals = ', '.join(f'«{v}»' for v in s[bad].astype(str).unique()[:6])
                    note('не число', c, bad.sum(), bad, vals)
                num = conv.map(lambda t: t[0])
                z = num.eq(0)
                if z.any():
                    note('нули', c, z.sum(), z)
                q = pd.to_numeric(num, errors='coerce')
                if q.notna().sum() > 10:
                    hi = q > q.quantile(0.75) + 3 * (q.quantile(0.75) - q.quantile(0.25))
                    if hi.any():
                        note('очень большие значения', c, hi.sum(), hi, 'самые большие: ' + ', '.join(f'{v:g}' for v in q[hi].sort_values(ascending=False).head(5)))
            elif it['type'] in ('single', 'split', 'scale', 'scale010') and it['codes']:
                v = pd.to_numeric(s, errors='coerce')
                out = s.notna() & ~v.isin(list(it['codes']))
                if out.any():
                    note('коды вне карты', c, out.sum(), out, 'значения: ' + ', '.join(map(str, s[out].unique()[:6])))
                if it['type'] == 'scale':
                    svc = v.isin([k for k in it['codes'] if k >= 96])
                    if svc.any():
                        note('служебный код в шкале', c, svc.sum(), svc, 'не точка шкалы: в среднее не входит')
            elif it['type'] == 'multi':
                v = pd.to_numeric(s, errors='coerce')
                out = s.notna() & ~v.isin([0, 1])
                if out.any():
                    note('в мультивыборе не 0 и не 1', c, out.sum(), out)
            elif it['type'] == 'yesno':
                v = pd.to_numeric(s, errors='coerce')
                out = s.notna() & ~v.isin([1, 2])
                if out.any():
                    note('в «да или нет» не 1 и не 2', c, out.sum(), out)
            if it['type'] not in ('open', 'text'):
                gap = sh & s.isna()
                if gap.any():
                    note('пусто у тех, кому вопрос показан', c, gap.sum(), gap, 'пропуск, «другое» без кода или ошибка логики — посмотреть')
            extra_ans = ~sh & s.notna() & (s.astype(str).str.strip() != '')
            if extra_ans.any():
                note('ответ у тех, кому вопрос не показан', c, extra_ans.sum(), extra_ans, 'логика показа в платформе не та, что в карте')
        if it['type'] == 'multi':
            m = df[cols].apply(pd.to_numeric, errors='coerce')
            none = sh & m.fillna(0).sum(axis=1).eq(0) & m.notna().any(axis=1)
            if none.any():
                note('мультивыбор без единого отмеченного варианта', it['id'], none.sum(), none)
        if it['type'] == 'text':
            t = df.loc[sh, cols[0]].dropna().astype(str).str.strip().str.lower()
            if len(t):
                top = t.value_counts().head(10)
                print(f"  {cols[0]}: частые ответы в «Другом» — " + '; '.join(f'«{k}» {v}' for k, v in top.items()) + ' — нет ли среди них готовых вариантов?')

    print('\n== Кандидаты на чистку (не удалены — правила берутся из паспорта)')
    svc = [c for it in items if it['type'] == 'service' for c in it['cols'] if c in df.columns]
    ans = [c for c in df.columns if c not in svc]
    st = next((c for c in svc if re.search(r'status|статус', c, re.I)), None)
    test = pd.Series(False, index=df.index)
    if st:
        test |= df[st].astype(str).str.lower().str.contains('тест|test', na=False)
    for c in df.columns:
        if df[c].dtype == object and c not in svc:
            test |= df[c].astype(str).str.strip().str.lower().isin(['тест', 'test', 'проверка'])
    note('похоже на тестовые анкеты', 'все', test.sum(), test, f'статус «тест» в {st}' if st else 'ответы «тест»')
    pid = next((c for c in svc if re.search(r'panel|участник|user', c, re.I)), None)
    if pid:
        d = df[pid].notna() & df.duplicated(pid, keep='first')
        note(f'повтор номера участника {pid} (вторая и дальше)', 'все', d.sum(), d)
    same = df.duplicated(ans, keep='first')
    both = same & (d if pid else False)
    note('совпадает профиль ответов (повторное участие не доказано)', 'все', same.sum(), same,
         'сравнены все колонки ответов' + (f'; из них {int(both.sum())} — ещё и повтор номера участника' if pid else ''))
    dur = next((c for c in svc if re.search(r'duration|длительн', c, re.I)), None)
    if dur:
        x = pd.to_numeric(df[dur], errors='coerce')
        med = x.median()
        fast = x < med / 3
        note('быстрее трети медианы', 'все', fast.sum(), fast, f'медиана {med:g} с, треть — {med / 3:.0f} с')
    grids = [it for it in items if it['type'] in ('yesno',) and len(it['cols']) >= 4]
    for it in grids:
        m = df[[c for c in it['cols'] if c in df.columns]].apply(pd.to_numeric, errors='coerce')
        flat = m.notna().all(axis=1) & m.nunique(axis=1).eq(1)
        note(f'одинаковый ответ во всех пунктах {it["id"]}', it['id'], flat.sum(), flat, 'само по себе не повод удалять — смотреть вместе со скоростью')
    if a.json:
        json.dump(rep, open(a.json, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    print('\nГотово. Что из этого чистить — решает правило паспорта. Правила нет — предложите его исследователю и подождите ответа.')


if __name__ == '__main__':
    main()
