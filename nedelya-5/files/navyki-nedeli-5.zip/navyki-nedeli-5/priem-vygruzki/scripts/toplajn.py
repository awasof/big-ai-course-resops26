#!/usr/bin/env python3
"""Топлайн по карте данных: у каждой таблицы база и от кого процент, у каждой доли — интервал Уилсона.

  python3 toplajn.py data/chistaya.csv 01_карта-данных.md --out tables/toplajn.xlsx [--kontrol Q1=1 M1=1,2@Q1=1 …] [--min-baza 30 --malaya 100]

Правила по типам вопросов (как в паспорте курса):
  один ответ, сплит       — % от тех, кому показан вопрос; «нет ответа» — отдельной строкой; сумма = 100%, иначе стоп
  несколько ответов       — % от людей, кому показан вопрос; сумма больше 100% — норма
  да или нет по пунктам   — % «да» по каждому пункту от тех, кому показан вопрос
  шкала                   — распределение; служебные коды 96–99 отдельно и не входят в топ-2 и среднее
  шкала 0–10              — распределение ответов
  число                   — текст переводится в число («2к» → 2000); медиана и квартили; нули и выбросы — отдельно
  открытый, текст         — сколько ответов; доли кодов считает навык кодирования
--kontrol: контрольные числа на экран. «Q1=1» — доля Q1 = 1 от тех, кому показан Q1;
           «M1=1,2@Q1=1» — доля M1 = 1 или 2 среди строк, где Q1 = 1.
Не сошлось (сумма одного ответа не 100%, база больше строк) — сообщение «НЕ СОШЛОСЬ» и код выхода 2.
"""
import sys, argparse, pathlib, re
import pandas as pd
import numpy as np
from karta import load, read_export, shown
from chisla import to_number
from stat_oprosa import wilson, chislo

SVC = (96, 97, 98, 99)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('vygruzka'); ap.add_argument('karta')
    ap.add_argument('--out', default='tables/toplajn.xlsx'); ap.add_argument('--kontrol', nargs='*', default=[])
    ap.add_argument('--min-baza', type=int, default=30); ap.add_argument('--malaya', type=int, default=100)
    a = ap.parse_args()
    items = load(a.karta)
    df = read_export(a.vygruzka)
    N = len(df)
    rows, problems = [], []

    def add(it, base_n, label, k, note=''):
        p, lo, hi = wilson(k, base_n)
        rows.append({'вопрос': it['id'], 'текст': it['q'], 'кому показан': it['base_text'] or 'все', 'база, n': base_n,
                     'вариант': label, 'n': k, '%': round(p, 1), 'низ 95%': round(lo, 1), 'верх 95%': round(hi, 1), 'примечание': note})

    print(f'== Строк в выгрузке после чистки: {N}')
    print('== База каждого вопроса')
    for it in items:
        cols = [c for c in it['cols'] if c in df.columns]
        if not cols or it['type'] == 'service':
            continue
        sh = shown(df, it)
        n = int(sh.sum())
        print(f"  {it['id']}: {n} — {it['base_text'] or 'все'}")
        if n > N:
            problems.append(f"{it['id']}: база больше числа строк")
        t = it['type']
        if t in ('single', 'split', 'scale', 'scale010'):
            v = pd.to_numeric(df.loc[sh, cols[0]], errors='coerce')
            tot = 0
            for code, lab in it['codes'].items():
                k = int((v == code).sum()); tot += k
                add(it, n, f'{code} {lab}', k, 'служебный код' if code in SVC else '')
            na = int(v.isna().sum()); tot += na
            if na:
                add(it, n, 'нет ответа', na, 'пусто у тех, кому показан')
            other = n - tot
            if other:
                add(it, n, 'код вне карты', other, 'проверить приём выгрузки')
            s = round(sum(r['%'] for r in rows if r['вопрос'] == it['id'] and r['текст'] == it['q']), 1)
            if abs(100 * tot / n - 100) > 1e-9 if n else False:
                problems.append(f"{it['id']}: строки вариантов не дают базу ({tot} из {n})")
            if t == 'scale':
                pts = sorted(c for c in it['codes'] if c not in SVC)
                valid = v[v.isin(pts)]
                top2 = pts[-2:]
                add(it, len(valid), f'топ-2 ({" и ".join(map(str, top2))}), без служебных кодов', int(valid.isin(top2).sum()), 'база — ответившие по шкале')
                rows[-1]['среднее'] = round(valid.mean(), 2) if len(valid) else None
        elif t == 'multi':
            m = df.loc[sh, cols].apply(pd.to_numeric, errors='coerce')
            for c in cols:
                code = int(re.findall(r'(\d+)$', c)[0]) if re.findall(r'(\d+)$', c) else c
                add(it, n, f"{code} {it['codes'].get(code, c)}", int((m[c] == 1).sum()), '% от людей')
            ment = int((m == 1).sum().sum())
            if n:
                print(f"     {it['id']}: отметок {ment} на {n} человек — {ment / n:.2f} на человека; сумма % от людей больше 100% — так и должно быть")
        elif t == 'yesno':
            m = df.loc[sh, cols].apply(pd.to_numeric, errors='coerce')
            for i, c in enumerate(cols, 1):
                code = int(re.findall(r'(\d+)$', c)[0])
                add(it, n, f"{code} {it['codes'].get(code, c)}: да", int((m[c] == 1).sum()), '1 — да, 2 — нет')
        elif t == 'number':
            conv = df.loc[sh, cols[0]].map(to_number)
            num = pd.Series([x[0] for x in conv], dtype=float)
            how = pd.Series([x[1] for x in conv])
            ok = num.dropna()
            q1, q3 = ok.quantile(0.25), ok.quantile(0.75)
            big = ok > q3 + 3 * (q3 - q1)
            clean = ok[(ok > 0) & ~big]
            rows.append({'вопрос': it['id'], 'текст': it['q'], 'кому показан': it['base_text'] or 'все', 'база, n': n,
                         'вариант': 'медиана [квартили], без нулей и выбросов', 'n': len(clean),
                         '%': None, 'медиана': clean.median(), 'квартиль 25%': clean.quantile(0.25), 'квартиль 75%': clean.quantile(0.75),
                         'среднее': round(clean.mean(), 1),
                         'примечание': f"текст → число {int((how == 'текст → число').sum())}, не число {int((how == 'не число').sum())}, пусто {int((how == 'пусто').sum())}, "
                                       f"нули {int((ok == 0).sum())}, выбросы выше Q3 + 3×IQR {int(big.sum())} ({', '.join(f'{x:g}' for x in ok[big].sort_values(ascending=False))}); "
                                       f"среднее со всем — {ok.mean():.1f}"})
        elif t in ('open', 'text'):
            s = df.loc[sh, cols[0]]
            k = int((s.notna() & (s.astype(str).str.strip() != '')).sum())
            add(it, n, 'есть ответ', k, 'доли кодов — после разметки по кодбуку')

    out = pathlib.Path(a.out); out.parent.mkdir(parents=True, exist_ok=True)
    tab = pd.DataFrame(rows)
    def porog(r):                                  # пороги базы из паспорта: меньше 30 — не показываем, 30–99 — «малая база»
        n = r['база, n']
        if n < a.min_baza:
            return 'база мала — не показываем'
        return 'малая база' if n < a.malaya else ''
    tab.insert(4, 'база', tab.apply(porog, axis=1))
    tab.to_excel(out, index=False, sheet_name='Топлайн')
    print(f'\n== Таблица: {out}, строк {len(tab)}')

    if a.kontrol:
        print('\n== Контрольные числа (для сверки с платформой и с независимым пересчётом)')
    for k in a.kontrol:
        m = re.match(r'^(\w+)=([\d,]+)(?:@(\w+)=([\d,]+))?$', k)
        if not m:
            print(f'  не понимаю «{k}»'); continue
        col, vals = m.group(1), [float(x) for x in m.group(2).split(',')]
        if m.group(3):
            base = pd.to_numeric(df[m.group(3)], errors='coerce').isin([float(x) for x in m.group(4).split(',')])
            btxt = f'{m.group(3)} = {m.group(4)}'
        else:
            it = next((i for i in items if col in i['cols']), None)
            base = shown(df, it) if it else pd.Series(True, index=df.index)
            btxt = (it['base_text'] if it else '') or 'все строки'
        x = pd.to_numeric(df.loc[base, col], errors='coerce')
        kk, nn = int(x.isin(vals).sum()), int(base.sum())
        p, lo, hi = wilson(kk, nn)
        print(f'  {col} = {m.group(2)}: {kk} из {nn} ({btxt}) — {chislo(p)}% [{chislo(lo)}; {chislo(hi)}]')
    if problems:
        print('\nНЕ СОШЛОСЬ:'); [print('  ' + p) for p in problems]
        print('Остановитесь и разберитесь, прежде чем идти дальше.')
        sys.exit(2)
    print('\nВсё сходится: у каждой таблицы база и от кого процент.')


if __name__ == '__main__':
    main()
