#!/usr/bin/env python3
"""Водопад чистки: правила из паспорта применяются по очереди, у каждого — сколько строк ушло.
Сырой файл не меняется: чистая выгрузка и список исключённых пишутся отдельными файлами.

  python3 vodopad.py raw/выгрузка.csv 01_карта-данных.md pravila-chistki.json --out data/chistaya.csv

pravila-chistki.json — правила в порядке применения (переписываются из паспорта, а не придумываются):
[
  {"pravilo": "тестовые анкеты", "isklyuchit": "status == 'Тест' or panel_id.isna()"},
  {"pravilo": "повтор номера участника", "povtor_po": "panel_id", "ostavit": "первую", "poryadok": "start_time"},
  {"pravilo": "анкета повторяет другую", "kopii": "все колонки ответов", "poryadok": "start_time"},
  {"pravilo": "слишком быстрые", "dlitelnost": "duration_sec", "dolya_mediany": 0.3333, "mediana": "по всем строкам"}
]
  isklyuchit    — условие на языке pandas (DataFrame.query): какие строки убрать
  povtor_po     — колонка; из повторов остаётся первая (или последняя) по колонке poryadok
  kopii         — убрать анкеты, у которых все ответы совпадают с более ранней по колонке poryadok
                  (без poryadok — по порядку строк); служебные колонки из карты не сравниваются
  dlitelnost    — убрать тех, кто быстрее dolya_mediany × медиана; медиана «по всем строкам» сырого файла или «после предыдущих правил»

Печатает таблицу «было → минус правило → осталось» и проверяет, что строки сходятся. Не сошлось — код выхода 2.
"""
import sys, json, argparse, pathlib
import pandas as pd
from karta import load, read_export


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('vygruzka'); ap.add_argument('karta'); ap.add_argument('pravila')
    ap.add_argument('--out', default='data/chistaya.csv'); ap.add_argument('--isklyuchennye', default=None)
    ap.add_argument('--podtverzhdayu-pravilo-skorosti', action='store_true', help='Только после явного подтверждения пользователем конкретного правила скорости')
    a = ap.parse_args()
    items = load(a.karta)
    raw = read_export(a.vygruzka)
    rules = json.loads(pathlib.Path(a.pravila).read_text(encoding='utf-8'))
    speed_rules = [r for r in rules if 'dlitelnost' in r]
    if speed_rules and not a.podtverzhdayu_pravilo_skorosti:
        for r in speed_rules:
            col = r['dlitelnost']
            if col not in raw.columns:
                sys.exit(f'Нет колонки длительности: {col}. Правило скорости не применено.')
            values = pd.to_numeric(raw[col], errors='coerce')
            med = values.median()
            cutoff = float(r.get('dolya_mediany', 1 / 3)) * med
            print(f"Сигнал скорости: правило «{r.get('pravilo', 'без названия')}», параметры: {r}")
            print(f'Предварительно по сырому файлу: медиана {med:g} с; порог {cutoff:g} с; кандидатов {int((values < cutoff).sum())}. После предыдущих правил число может отличаться.')
        sys.exit('Остановлено до записи файлов: покажите правило пользователю и получите явное подтверждение; после этого повторите с --podtverzhdayu-pravilo-skorosti.')
    svc = {c for it in items if it['type'] == 'service' for c in it['cols']}
    idcol = next((c for c in raw.columns if c in svc and ('id' in c.lower() or 'номер' in c.lower()) and raw[c].is_unique), None)
    df = raw.copy()
    rows, gone = [], []
    print(f'Было: {len(df)} строк')
    for r in rules:
        name = r['pravilo']
        if 'isklyuchit' in r:
            idx = df.query(r['isklyuchit'], engine='python').index
        elif 'povtor_po' in r:
            col = r['povtor_po']
            d = df[df[col].notna()]
            if r.get('poryadok'):
                d = d.sort_values(r['poryadok'], kind='stable')
            keep = 'last' if str(r.get('ostavit', 'первую')).startswith('послед') else 'first'
            idx = d[d.duplicated(col, keep=keep)].index
        elif 'kopii' in r:
            cols = [c for c in df.columns if c not in svc]
            d = df.sort_values(r['poryadok'], kind='stable') if r.get('poryadok') else df   # «более ранняя» — по колонке poryadok
            idx = d[d.duplicated(cols, keep='first')].index
        elif 'dlitelnost' in r:
            col = r['dlitelnost']
            base = raw if str(r.get('mediana', 'по всем строкам')).startswith('по всем') else df
            med = pd.to_numeric(base[col], errors='coerce').median()
            thr = float(r.get('dolya_mediany', 1 / 3)) * med
            idx = df[pd.to_numeric(df[col], errors='coerce') < thr].index
            name = f"{name} (меньше {thr:.0f} с: {r.get('dolya_mediany', 1/3):.2f} × медиана {med:g} с)"
        else:
            sys.exit(f'Не понимаю правило: {r}')
        n0 = len(df)
        ex = df.loc[idx]
        gone.append(ex.assign(_pravilo=r['pravilo']))
        df = df.drop(idx)
        rows.append((name, n0, len(idx), len(df)))
        primer = ', '.join(str(x) for x in (ex[idcol].head(4).tolist() if idcol else list(idx[:4])))
        print(f'  − {len(idx):>5}  {name}' + (f'  — например {primer}' if len(idx) else ''))
    print(f'Осталось: {len(df)} строк')
    ok = len(raw) - sum(r[2] for r in rows) == len(df)
    print('Строки сходятся:', 'да' if ok else 'НЕТ — остановитесь и проверьте правила')
    out = pathlib.Path(a.out); out.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(out, index=False, encoding='utf-8')
    exf = pathlib.Path(a.isklyuchennye or out.with_name('isklyuchennye.csv'))
    if gone:
        pd.concat(gone)[[c for c in ([idcol] if idcol else []) + ['_pravilo']]].to_csv(exf, index=not idcol, encoding='utf-8')
    tab = pd.DataFrame(rows, columns=['правило', 'было', 'исключено', 'осталось'])
    tab.to_csv(out.with_name('vodopad.csv'), index=False, encoding='utf-8')
    print(f'Чистая выгрузка — {out}, исключённые с правилом — {exf}, таблица водопада — {out.with_name("vodopad.csv")}')
    sys.exit(0 if ok else 2)


if __name__ == '__main__':
    main()
