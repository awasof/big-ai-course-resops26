#!/usr/bin/env python3
"""Согласие двух разметок открытых ответов: процент совпадений, каппа Коэна по каждому коду,
точность и полнота против эталона, пары кодов, которые путаются, и номера ответов, где разошлись.

  python3 soglasie.py razmetka_A.csv razmetka_B.csv [--kodbuk kodbuk.md --vopros OA2] [--etalon B] [--out coding/soglasie.md]

Файлы — в любом виде, который читает razmetka.py: широкий (OA2_1 … = 1/0), длинный (id, codes) или JSON.
--etalon B — вторая разметка ваша ручная (контрольная выборка вслепую): тогда считаются точность и полнота модели.
Сравниваются только ответы, которые есть в обеих разметках.

Пороги каппы — как в части 4 курса: от 0,8 — надёжно; 0,67–0,8 — только для предварительных выводов;
ниже 0,67 — кодбук не готов: правьте определения («что входит», «что не входит»), а не промпт, и проверяйте на новой выборке.
"""
import argparse, pathlib, collections
from razmetka import read_coding
from kodbuk import load_codebook


def kappa(a, b):
    n = len(a)
    if n == 0:
        return float('nan')
    po = sum(x == y for x, y in zip(a, b)) / n
    pa, pb = sum(a) / n, sum(b) / n
    pe = pa * pb + (1 - pa) * (1 - pb)
    return 1.0 if pe == 1 else (po - pe) / (1 - pe)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('a'); ap.add_argument('b'); ap.add_argument('--kodbuk'); ap.add_argument('--vopros')
    ap.add_argument('--etalon', choices=['B', 'нет'], default='нет'); ap.add_argument('--out')
    x = ap.parse_args()
    names = load_codebook(x.kodbuk, x.vopros) if x.kodbuk else {}
    A, B = read_coding(x.a, names=names), read_coding(x.b, names=names)
    ids = sorted(set(A) & set(B), key=lambda s: (len(s), s))
    L = []
    L.append(f'Ответов в обеих разметках: {len(ids)} (только в первой — {len(set(A) - set(B))}, только во второй — {len(set(B) - set(A))})')
    same = sum(A[i] == B[i] for i in ids)
    L.append(f'Набор кодов совпал полностью: {same} из {len(ids)} — {100 * same / len(ids):.1f}%')
    codes = sorted(set().union(*[A[i] for i in ids], *[B[i] for i in ids]) | set(names))
    L.append('')
    head = '| Код | Название | в А | в Б | совпадение, % | каппа |' + (' точность | полнота |' if x.etalon == 'B' else '')
    L.append(head); L.append('|' + '---|' * (head.count('|') - 1))
    ks = []
    for c in codes:
        a = [int(c in A[i]) for i in ids]; b = [int(c in B[i]) for i in ids]
        if not any(a) and not any(b):
            continue
        k = kappa(a, b); ks.append((k, c))
        agree = 100 * sum(p == q for p, q in zip(a, b)) / len(ids)
        row = f'| {c} | {names.get(c, "")} | {sum(a)} | {sum(b)} | {agree:.1f} | {k:.2f} |'
        if x.etalon == 'B':
            tp = sum(p and q for p, q in zip(a, b))
            prec = tp / sum(a) if sum(a) else float('nan'); rec = tp / sum(b) if sum(b) else float('nan')
            row += f' {prec:.2f} | {rec:.2f} |'
        L.append(row)
    L.append('')
    weak = [(k, c) for k, c in ks if k < 0.8]
    for k, c in sorted(weak):
        lvl = 'только для предварительных выводов' if k >= 0.67 else 'кодбук не готов'
        L.append(f'- Код {c} «{names.get(c, "")}»: каппа {k:.2f} — {lvl}')
    if not weak:
        L.append('- Каппа по всем кодам от 0,8 — надёжно')
    conf = collections.Counter()
    where = collections.defaultdict(list)
    for i in ids:
        for ca in A[i] - B[i]:
            for cb in B[i] - A[i]:
                conf[(ca, cb)] += 1; where[(ca, cb)].append(i)
    if conf:
        L += ['', 'Пары, которые путаются (в А стоит первый код, в Б — второй):']
        for (ca, cb), n in conf.most_common(8):
            L.append(f'- {ca} «{names.get(ca, "")}» ↔ {cb} «{names.get(cb, "")}»: {n} — ответы {", ".join(where[(ca, cb)][:6])}')
    only = collections.Counter()
    for i in ids:
        if A[i] != B[i] and not (A[i] - B[i] and B[i] - A[i]):
            for c in (A[i] ^ B[i]):
                only[(c, 'лишний в А' if c in A[i] else 'лишний в Б')] += 1
    if only:
        L += ['', 'Код поставлен только в одной разметке, без замены:']
        for (c, s), n in only.most_common(8):
            L.append(f'- {c} «{names.get(c, "")}» — {s}: {n}')
    diff = [i for i in ids if A[i] != B[i]]
    L += ['', f'Ответы, где разметки разошлись ({len(diff)}): ' + ', '.join(diff[:40]) + (' …' if len(diff) > 40 else '')]
    txt = '\n'.join(L)
    print(txt)
    if x.out:
        pathlib.Path(x.out).parent.mkdir(parents=True, exist_ok=True)
        pathlib.Path(x.out).write_text('# Согласие разметки\n\n' + txt + '\n', encoding='utf-8')


if __name__ == '__main__':
    main()
