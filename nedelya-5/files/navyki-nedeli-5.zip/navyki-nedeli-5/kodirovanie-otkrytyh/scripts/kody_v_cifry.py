#!/usr/bin/env python3
"""Открытый вопрос в цифрах: доля каждого кода от людей, интервал Уилсона, сравнение групп с поправкой Холма.

  python3 kody_v_cifry.py razmetka.csv data/chistaya.csv --kodbuk kodbuk.md --vopros OA2 --id response_id
        [--net 98] [--karta 01_карта-данных.md]
        [--gruppy "18–29=S1 <= 29" "60+=S1 >= 60"] [--out tables/oa2-v-cifrah.xlsx]

1. Разметка соединяется с выгрузкой по номеру ответа: остаются только совпавшие строки.
2. База — ответившие по существу: те, у кого только код --net («нет ответа или не по вопросу»), исключаются.
3. Доля кода — % людей с этим кодом от базы, не от упоминаний; сумма долей больше 100% — норма при нескольких кодах.
4. --gruppy — две группы для сравнения (условия на языке pandas). По каждому коду: доли, разница с интервалом
   Ньюкомба, p, поправка Холма на число кодов, вердикт по правилам курса.
С --karta колонки типа «число» (например, возраст текстом) переводятся в число до сравнения.
"""
import argparse, pathlib, sys
import pandas as pd
from razmetka import read_coding, _id
from kodbuk import load_codebook
from karta import read_export, load
from chisla import to_number
from stat_oprosa import wilson, newcomb, p_dvuh_dolej, holm, verdikt, chislo


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('razmetka'); ap.add_argument('vygruzka')
    ap.add_argument('--kodbuk', required=True); ap.add_argument('--vopros'); ap.add_argument('--id', default='response_id')
    ap.add_argument('--net', type=int, default=98); ap.add_argument('--karta'); ap.add_argument('--gruppy', nargs=2)
    ap.add_argument('--min-baza', type=int, default=30)
    ap.add_argument('--out', default='tables/kody-v-cifrah.xlsx')
    a = ap.parse_args()
    names = load_codebook(a.kodbuk, a.vopros)
    C = read_coding(a.razmetka, prefix=a.vopros, names=names)
    df = read_export(a.vygruzka)
    if a.karta:
        for it in load(a.karta):
            if it['type'] == 'number':
                for c in it['cols']:
                    if c in df.columns:
                        df[c] = pd.to_numeric(df[c].map(lambda x: to_number(x)[0]), errors='coerce')
    df['_id'] = df[a.id].map(_id)
    if df['_id'].isin(['', 'nan', 'None', 'NaN']).any():
        sys.exit('ОСТАНОВКА: пустой номер ответа в выгрузке.')
    if df['_id'].duplicated().any():
        sys.exit('ОСТАНОВКА: повторяющиеся номера ответов в выгрузке; проверьте соединение.')
    n_v = len(df)
    raw_ids = set(df['_id'])
    coding_ids = set(C)
    if raw_ids != coding_ids:
        sys.exit(f'ОСТАНОВКА: базы выгрузки и разметки различаются: без разметки {len(raw_ids-coding_ids)}, нет в выгрузке {len(coding_ids-raw_ids)}. Сверьте ID и согласованные правила; передайте согласованные файлы одной базы.')
    df = df[df['_id'].isin(C)].copy()
    print(f'Строк в выгрузке {n_v}, в разметке {len(C)}, совпало по номеру {len(df)}')
    if len(df) < len(C):
        print(f'  ВНИМАНИЕ: {len(C) - len(df)} номеров из разметки нет в выгрузке — проверьте, та ли выгрузка')
    df['_k'] = df['_id'].map(C)
    only_net = df['_k'].map(lambda s: s == frozenset({a.net}) or len(s) == 0)
    base = df[~only_net]
    n = len(base)
    print(f'Исключено как «{names.get(a.net, "нет ответа")}» или без кода: {int(only_net.sum())}; база — {n} ответивших по существу')
    if not n:
        sys.exit('ОСТАНОВКА: нет ответов в базе после соединения и исключений.')
    ment = sum(len(s - {a.net}) for s in base['_k'])
    print(f'Отметок кодов {ment} — {ment / n:.2f} на ответ: сумма долей от людей больше 100%, так и должно быть\n')
    codes = [c for c in names if c != a.net]
    rows = []
    for c in codes:
        k = int(base['_k'].map(lambda s: c in s).sum())
        p, lo, hi = wilson(k, n)
        rows.append({'код': c, 'название': names[c], 'n': k, '% от ответивших': round(p, 1), 'низ 95%': round(lo, 1), 'верх 95%': round(hi, 1)})
    T = pd.DataFrame(rows).sort_values('% от ответивших', ascending=False)
    print(f'База — {n} ответивших по существу; интервал — Уилсон, 95%')
    for _, r in T.iterrows():
        print(f"  {r['название']}: {r['n']} — {chislo(r['% от ответивших'])}% [{chislo(r['низ 95%'])}; {chislo(r['верх 95%'])}]")
    out = pathlib.Path(a.out); out.parent.mkdir(parents=True, exist_ok=True)
    sheets = {'Доли кодов': T}
    if a.gruppy:
        (na, ea), (nb, eb) = [g.split('=', 1) for g in a.gruppy]
        A = base[base.eval(ea, engine='python').fillna(False).astype(bool)]
        B = base[base.eval(eb, engine='python').fillna(False).astype(bool)]
        if len(A.index.intersection(B.index)):
            sys.exit('ОСТАНОВКА: группы пересекаются; независимый метод неприменим.')
        if not len(A) or not len(B):
            sys.exit('ОСТАНОВКА: одна из групп пуста.')
        res = []
        for c in codes:
            k1, k2 = int(A['_k'].map(lambda s: c in s).sum()), int(B['_k'].map(lambda s: c in s).sum())
            d, lo, hi = newcomb(k1, len(A), k2, len(B))
            p, test = p_dvuh_dolej(k1, len(A), k2, len(B))
            res.append({'код': c, 'название': names[c], na: round(100 * k1 / len(A), 1) if len(A) else None, nb: round(100 * k2 / len(B), 1) if len(B) else None,
                        'разница, п.п.': d, 'низ': lo, 'верх': hi, 'p': p, 'тест': test})
        R = pd.DataFrame(res)
        ok, adj = holm(R['p'].tolist())
        R['p с поправкой Холма'] = adj
        R['вердикт'] = [verdikt(r['низ'], r['верх'], o, len(A), len(B), None, a.min_baza) for (_, r), o in zip(R.iterrows(), ok)]   # по точному интервалу, не по округлённому
        R = R.sort_values('разница, п.п.')
        print(f'\nСравнение: {na} (n = {len(A)}) против {nb} (n = {len(B)}); обычный интервал разницы — Ньюкомб; поправка Холма применяется к p отдельно на {len(codes)} кодов')
        for _, r in R.iterrows():
            print(f"  {r['название']}: {chislo(r[na])}% против {chislo(r[nb])}% → {chislo(r['разница, п.п.'], 1, True)} п.п. "
                  f"[{chislo(r['низ'], 1, True)}; {chislo(r['верх'], 1, True)}] → {r['вердикт']}")
        sheets['Сравнение'] = R
    with pd.ExcelWriter(out) as w:
        for k, v in sheets.items():
            v.to_excel(w, sheet_name=k, index=False)
    print(f'\nТаблицы — {out}. Слова «чаще», «реже», «одинаково» — только из столбца «вердикт».')


if __name__ == '__main__':
    main()
