"""Статистика опроса без сюрпризов: каждый метод назван явно, умолчаний библиотек нет.

Нужны только numpy и scipy. Импорт из скрипта рядом:  from stat_oprosa import wilson, newcomb, ...

  wilson(k, n)                      — доля и 95% интервал Уилсона, в процентах
  newcomb(k1, n1, k2, n2)           — разница долей А − Б в п.п. и интервал Ньюкомба (метод 10, гибридный счёт Уилсона)
  p_dvuh_dolej(k1, n1, k2, n2)      — точное p: z-тест для двух долей; при ожидаемых частотах < 5 — точный тест Фишера
  holm(p_list)                      — поправка Холма: список «подтверждено после поправки» и скорректированные p
  cohen_h(p1, p2)                   — размер эффекта для долей
  welch(x, y)                       — разница средних и интервал Уэлча
  nps(x) / nps_bootstrap(x)         — NPS: % 9–10 минус % 0–6, интервал — бутстрэп
  verdikt(lo, hi, podtverzhdeno, n1, n2, porog=5, min_baza=30, malaya=100)
                                    — один из трёх вердиктов по правилам курса
"""
import math
import numpy as np
from scipy import stats

Z95 = 1.959963984540054


def _z(uroven=0.95):
    return Z95 if abs(uroven - 0.95) < 1e-12 else stats.norm.ppf(1 - (1 - uroven) / 2)


def wilson(k, n, uroven=0.95):
    """Доля k из n и интервал Уилсона. Возвращает (доля, низ, верх) в процентах; при n = 0 — (nan, nan, nan)."""
    if n == 0:
        return (math.nan, math.nan, math.nan)
    z = _z(uroven)
    p = k / n
    d = 1 + z * z / n
    c = (p + z * z / (2 * n)) / d
    h = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / d
    return (100 * p, 100 * max(0.0, c - h), 100 * min(1.0, c + h))


def newcomb(k1, n1, k2, n2, uroven=0.95):
    """Разница долей А − Б в п.п. и интервал Ньюкомба (метод 10: на интервалах Уилсона каждой доли)."""
    if n1 == 0 or n2 == 0:
        return (math.nan, math.nan, math.nan)
    p1, p2 = k1 / n1, k2 / n2
    _, l1, u1 = wilson(k1, n1, uroven)
    _, l2, u2 = wilson(k2, n2, uroven)
    l1, u1, l2, u2 = l1 / 100, u1 / 100, l2 / 100, u2 / 100
    d = p1 - p2
    lo = d - math.sqrt((p1 - l1) ** 2 + (u2 - p2) ** 2)
    hi = d + math.sqrt((u1 - p1) ** 2 + (p2 - l2) ** 2)
    return (100 * d, 100 * lo, 100 * hi)


def p_dvuh_dolej(k1, n1, k2, n2):
    """p для разницы двух долей. Возвращает (p, название теста)."""
    if n1 == 0 or n2 == 0:
        return (math.nan, 'нет данных')
    table = np.array([[k1, n1 - k1], [k2, n2 - k2]])
    exp = table.sum(0) * table.sum(1)[:, None] / table.sum()
    if (exp < 5).any():
        return (float(stats.fisher_exact(table)[1]), 'точный тест Фишера (ожидаемые частоты меньше 5)')
    p_pool = (k1 + k2) / (n1 + n2)
    se = math.sqrt(p_pool * (1 - p_pool) * (1 / n1 + 1 / n2))
    if se == 0:
        return (1.0, 'z-тест для двух долей')
    z = (k1 / n1 - k2 / n2) / se
    return (float(2 * stats.norm.sf(abs(z))), 'z-тест для двух долей')


def holm(pvals, alpha=0.05):
    """Поправка Холма на все сравнения семейства. Возвращает (подтверждено: list[bool], p с поправкой: list[float])."""
    m = len(pvals)
    order = sorted(range(m), key=lambda i: (math.inf if pvals[i] != pvals[i] else pvals[i]))
    adj = [math.nan] * m
    run = 0.0
    for rank, i in enumerate(order):
        p = pvals[i]
        if p != p:
            continue
        run = max(run, min(1.0, (m - rank) * p))
        adj[i] = run
    ok = [(a == a and a <= alpha) for a in adj]
    return ok, adj


def cohen_h(p1, p2):
    """h Коэна для двух долей (доли — от 0 до 1). 0,2 — маленький, 0,5 — средний, 0,8 — большой."""
    return 2 * math.asin(math.sqrt(p1)) - 2 * math.asin(math.sqrt(p2))


def welch(x, y, uroven=0.95):
    """Разница средних x − y и интервал Уэлча. Возвращает (разница, низ, верх, p)."""
    x, y = np.asarray(x, float), np.asarray(y, float)
    x, y = x[~np.isnan(x)], y[~np.isnan(y)]
    if len(x) < 2 or len(y) < 2:
        return (math.nan,) * 4
    vx, vy = x.var(ddof=1) / len(x), y.var(ddof=1) / len(y)
    se = math.sqrt(vx + vy)
    df = (vx + vy) ** 2 / (vx ** 2 / (len(x) - 1) + vy ** 2 / (len(y) - 1)) if se > 0 else 1
    t = stats.t.ppf(1 - (1 - uroven) / 2, df)
    d = x.mean() - y.mean()
    p = float(stats.ttest_ind(x, y, equal_var=False).pvalue) if se > 0 else 1.0
    return (d, d - t * se, d + t * se, p)


def nps(x):
    """NPS по шкале 0–10: % 9–10 минус % 0–6. Пустые и коды вне 0–10 не считаются."""
    x = np.asarray(x, float)
    x = x[(x >= 0) & (x <= 10)]
    if len(x) == 0:
        return math.nan
    return 100 * ((x >= 9).mean() - (x <= 6).mean())


def nps_bootstrap(x, povtorov=2000, uroven=0.95, zerno=20261117):
    """NPS и интервал бутстрэпом (процентильный). Возвращает (nps, низ, верх, n)."""
    x = np.asarray(x, float)
    x = x[(x >= 0) & (x <= 10)]
    n = len(x)
    if n == 0:
        return (math.nan, math.nan, math.nan, 0)
    rng = np.random.default_rng(zerno)
    s = np.where(x >= 9, 1.0, np.where(x <= 6, -1.0, 0.0))
    boots = s[rng.integers(0, n, size=(povtorov, n))].mean(1) * 100
    a = (1 - uroven) / 2
    return (100 * s.mean(), float(np.quantile(boots, a)), float(np.quantile(boots, 1 - a)), n)


def nps_raznica_bootstrap(x, y, povtorov=2000, uroven=0.95, zerno=20261117):
    """Разница NPS x − y и интервал бутстрэпом."""
    x, y = np.asarray(x, float), np.asarray(y, float)
    x, y = x[(x >= 0) & (x <= 10)], y[(y >= 0) & (y <= 10)]
    sx = np.where(x >= 9, 1.0, np.where(x <= 6, -1.0, 0.0))
    sy = np.where(y >= 9, 1.0, np.where(y <= 6, -1.0, 0.0))
    rng = np.random.default_rng(zerno)
    bx = sx[rng.integers(0, len(sx), size=(povtorov, len(sx)))].mean(1)
    by = sy[rng.integers(0, len(sy), size=(povtorov, len(sy)))].mean(1)
    b = 100 * (bx - by)
    a = (1 - uroven) / 2
    return (100 * (sx.mean() - sy.mean()), float(np.quantile(b, a)), float(np.quantile(b, 1 - a)))


def verdikt(lo, hi, podtverzhdeno, n1, n2, porog=5.0, min_baza=30, malaya=100):
    """Вердикт по правилам курса, в таком порядке:
    1) база меньше min_baza в любой группе — «база мала, не сравниваем»;
    2) интервал разницы не задевает ноль и поправка подтверждает — «разница есть»;
    3) интервал разницы целиком внутри ±porog — «практически одинаково»;
    4) иначе — «данных не хватает».
    К вердикту добавляется пометка «малая база», если в группе от min_baza до malaya − 1 человек.
    Границы сравниваются по точному интервалу, а не по округлённому: −5,04 — это за порогом ±5."""
    if min(n1, n2) < min_baza:
        return 'база мала, не сравниваем'
    pom = ' (малая база)' if min(n1, n2) < malaya else ''
    if (lo > 0 or hi < 0) and podtverzhdeno:
        return 'разница есть' + pom
    if lo >= -porog and hi <= porog:
        return 'практически одинаково' + pom
    return 'данных не хватает' + pom


def chislo(x, d=1, znak=False):
    """Число по-русски: запятая, минус «−», при znak=True — «+» у положительных."""
    if x != x:
        return '—'
    s = f'{abs(x):.{d}f}'.replace('.', ',')
    if x < 0 and float(s.replace(',', '.')) != 0:
        return '−' + s
    return ('+' if znak else '') + s
