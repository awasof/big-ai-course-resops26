#!/usr/bin/env python3
"""Выборки ответов на открытый вопрос: для кодбука и для контрольной ручной разметки — не пересекаются.

  python3 vyborka.py data/chistaya.csv --tekst OA2 --id response_id --kodbuk 250 --kontrol 100 [--zerno 1] [--papka coding]

coding/vyborka-dlya-kodbuka.csv — случайные ответы, по ним модель предлагает кодбук v1;
coding/kontrol-vslepuyu.csv     — другие случайные ответы с пустой колонкой kod_vruchnuyu: размечаете вы, вслепую,
                                  до того как увидите разметку модели. Пустые ответы в выборки не попадают.
"""
import argparse, pathlib
import pandas as pd
from karta import read_export


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('vygruzka'); ap.add_argument('--tekst', required=True); ap.add_argument('--id', default='response_id')
    ap.add_argument('--kodbuk', type=int, default=250); ap.add_argument('--kontrol', type=int, default=100)
    ap.add_argument('--zerno', type=int, default=1); ap.add_argument('--papka', default='coding')
    a = ap.parse_args()
    df = read_export(a.vygruzka)[[a.id, a.tekst]].dropna()
    df = df[df[a.tekst].astype(str).str.strip() != '']
    sh = df.sample(frac=1, random_state=a.zerno)
    kb, kt = sh.iloc[:a.kodbuk], sh.iloc[a.kodbuk:a.kodbuk + a.kontrol].assign(kod_vruchnuyu='')
    out = pathlib.Path(a.papka); out.mkdir(parents=True, exist_ok=True)
    kb.to_csv(out / 'vyborka-dlya-kodbuka.csv', index=False, encoding='utf-8')
    kt.to_csv(out / 'kontrol-vslepuyu.csv', index=False, encoding='utf-8')
    print(f'Ответов с текстом {len(df)}; для кодбука {len(kb)}, контрольная {len(kt)}; пересечений нет; зерно {a.zerno}')
    print(f'Файлы: {out}/vyborka-dlya-kodbuka.csv и {out}/kontrol-vslepuyu.csv — контрольную размечает человек, коды через «;»')


if __name__ == '__main__':
    main()
