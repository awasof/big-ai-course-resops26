#!/usr/bin/env python3
"""Строка сравнения: две группы, одна метрика, интервал разницы, поправка и вердикт — по правилам курса.

  python3 sravnenie.py data/chistaya.csv sravneniya.csv --karta 01_карта-данных.md --out tables/krossy.xlsx
        [--porog 5] [--min-baza 30] [--malaya 100] [--uroven 0.95] [--panel]

sravneniya.csv — по строке на сравнение из плана анализа (условия — на языке pandas, как в DataFrame.query;
условие с запятой внутри берите в кавычки):
  metrika,vid,uspeh,znachenie,baza,gruppa_a,gruppa_b,nazvanie_a,nazvanie_b,semejstvo
  Хотят подписку (K2 = 4–5),dolya,K2 >= 4,,"Q1 in [1, 2]",K1 == 1,K1 == 2,299 ₽,499 ₽,сплит цены
  Довольство Q6 (среднее 1–5),srednee,,Q6,Q1 == 1 and Q6 <= 5,"M1 in [1, 2]",M1 == 3,платят,не платят,довольство
  NPS основного сервиса,nps,,Q7,Q1 == 1,"M1 in [1, 2]",M1 == 3,платят,не платят,довольство

  vid        — dolya (доля), srednee (среднее, интервал Уэлча), nps (NPS, интервал бутстрэпом)
  uspeh      — для доли: условие «да» (у кого метрика выполнена)
  znachenie  — для среднего и NPS: колонка со значением
  baza       — кто входит в знаменатель (пусто — все строки); группы считаются внутри базы
  semejstvo  — сравнения одного семейства получают общую поправку Холма; пусто — всё в одном семействе

С --karta колонки типа «число» переводятся из текста в число («45 лет» → 45) до расчёта.
Вердикт: база < min-baza — «база мала»; интервал не задевает ноль и Холм подтверждает — «разница есть»;
интервал целиком внутри ±porog п.п. — «практически одинаково»; иначе — «данных не хватает».
--panel: выборка — онлайн-панель, интервалы условные (пометка в таблице).
"""
import sys, argparse, pathlib
import pandas as pd
import numpy as np
from stat_oprosa import wilson, newcomb, p_dvuh_dolej, holm, cohen_h, welch, nps, nps_bootstrap, nps_raznica_bootstrap, verdikt, chislo
from karta import load, read_export
from chisla import to_number


def mask(df, expr):
    expr = (expr or '').strip()
    if not expr or expr.lower() in ('все', 'nan'):
        return pd.Series(True, index=df.index)
    return df.eval(expr, engine='python').fillna(False).astype(bool)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('vygruzka'); ap.add_argument('sravneniya')
    ap.add_argument('--karta'); ap.add_argument('--out', default='tables/krossy.xlsx')
    ap.add_argument('--porog', type=float, default=5.0); ap.add_argument('--min-baza', type=int, default=30)
    ap.add_argument('--malaya', type=int, default=100); ap.add_argument('--uroven', type=float, default=0.95)
    ap.add_argument('--panel', action='store_true')
    a = ap.parse_args()
    df = read_export(a.vygruzka)
    if a.karta:
        for it in load(a.karta):
            if it['type'] == 'number':
                for c in it['cols']:
                    if c in df.columns:
                        df[c] = pd.to_numeric(df[c].map(lambda x: to_number(x)[0]), errors='coerce')
    S = pd.read_csv(a.sravneniya, dtype=str).fillna('')
    rows = []
    for _, r in S.iterrows():
        vid = (r.get('vid') or 'dolya').strip()
        b = mask(df, r.get('baza'))
        A = b & mask(df, r['gruppa_a']); B = b & mask(df, r['gruppa_b'])
        if (A & B).any():
            print(f"  ВНИМАНИЕ: «{r['metrika']}» — группы пересекаются ({int((A & B).sum())} строк). Строка сравнения неверна — остановитесь.")
        row = {'метрика': r['metrika'], 'семейство': r.get('semejstvo') or 'все', 'база': r.get('baza') or 'все',
               'А': r.get('nazvanie_a') or r['gruppa_a'], 'Б': r.get('nazvanie_b') or r['gruppa_b']}
        if vid == 'dolya':
            yes = mask(df, r['uspeh'])
            k1, n1, k2, n2 = int((A & yes).sum()), int(A.sum()), int((B & yes).sum()), int(B.sum())
            p1, l1, u1 = wilson(k1, n1, a.uroven); p2, l2, u2 = wilson(k2, n2, a.uroven)
            d, lo, hi = newcomb(k1, n1, k2, n2, a.uroven)
            p, test = p_dvuh_dolej(k1, n1, k2, n2)
            h = cohen_h(k1 / n1, k2 / n2) if n1 and n2 else float('nan')
            row.update({'А: значение': p1, 'А: n': n1, 'А: интервал': f'[{chislo(l1)}; {chislo(u1)}]',
                        'Б: значение': p2, 'Б: n': n2, 'Б: интервал': f'[{chislo(l2)}; {chislo(u2)}]',
                        'разница': d, 'низ': lo, 'верх': hi, 'тест': test + '; интервал разницы — Ньюкомб', 'p': p, 'эффект': f'h Коэна {chislo(h, 2)}',
                        'единица': 'п.п.'})
        elif vid == 'srednee':
            col = r['znachenie']
            x = pd.to_numeric(df.loc[A, col], errors='coerce').dropna(); y = pd.to_numeric(df.loc[B, col], errors='coerce').dropna()
            d, lo, hi, p = welch(x, y, a.uroven)
            sd = np.sqrt((x.var(ddof=1) + y.var(ddof=1)) / 2) if len(x) > 1 and len(y) > 1 else float('nan')
            row.update({'А: значение': x.mean(), 'А: n': len(x), 'А: интервал': '', 'Б: значение': y.mean(), 'Б: n': len(y), 'Б: интервал': '',
                        'разница': d, 'низ': lo, 'верх': hi, 'тест': 't-тест Уэлча (дисперсии не считаем равными)', 'p': p,
                        'эффект': f'd Коэна {chislo(d / sd, 2)}' if sd == sd and sd > 0 else '', 'единица': 'пункта шкалы'})
        elif vid == 'nps':
            col = r['znachenie']
            x = pd.to_numeric(df.loc[A, col], errors='coerce').values; y = pd.to_numeric(df.loc[B, col], errors='coerce').values
            v1, l1, u1, n1 = nps_bootstrap(x); v2, l2, u2, n2 = nps_bootstrap(y)
            d, lo, hi = nps_raznica_bootstrap(x, y)
            p = 0.0 if (lo > 0 or hi < 0) else 1.0
            row.update({'А: значение': v1, 'А: n': n1, 'А: интервал': f'[{chislo(l1)}; {chislo(u1)}]', 'Б: значение': v2, 'Б: n': n2,
                        'Б: интервал': f'[{chislo(l2)}; {chislo(u2)}]', 'разница': d, 'низ': lo, 'верх': hi,
                        'тест': 'бутстрэп, 2000 повторов; p не считается — решает интервал', 'p': float('nan'), 'эффект': '', 'единица': 'пункта NPS'})
        else:
            sys.exit(f"Не знаю вид «{vid}»: dolya, srednee или nps")
        row['выборка'] = 'онлайн-панель: интервал условный' if a.panel else ''
        rows.append(row)
    T = pd.DataFrame(rows)
    T['p с поправкой'] = np.nan; T['подтверждено'] = False
    for fam, g in T.groupby('семейство'):
        idx = [i for i in g.index if T.at[i, 'p'] == T.at[i, 'p']]
        if idx:
            ok, adj = holm([T.at[i, 'p'] for i in idx])
            for i, o, p2 in zip(idx, ok, adj):
                T.at[i, 'подтверждено'] = o; T.at[i, 'p с поправкой'] = p2
        for i in g.index:
            if T.at[i, 'p'] != T.at[i, 'p']:          # NPS: решает интервал
                T.at[i, 'подтверждено'] = (T.at[i, 'низ'] > 0 or T.at[i, 'верх'] < 0)
        T.loc[g.index, 'поправка'] = f'Холм на {len(idx)} сравнений семейства «{fam}»' if len(idx) > 1 else 'одно сравнение — без поправки'
    T['вердикт'] = [verdikt(r['низ'], r['верх'], r['подтверждено'], r['А: n'], r['Б: n'], a.porog, a.min_baza, a.malaya) for _, r in T.iterrows()]
    out = pathlib.Path(a.out); out.parent.mkdir(parents=True, exist_ok=True)
    T.to_excel(out, index=False, sheet_name='Сравнения')
    print(f'Правила: интервал {a.uroven:.0%}, порог «практически одинаково» ±{chislo(a.porog, 0)}, база меньше {a.min_baza} — не сравниваем, до {a.malaya} — «малая база»\n')
    for _, r in T.iterrows():
        u = r['единица']
        val = (lambda v: chislo(v)) if u != 'пункта шкалы' else (lambda v: chislo(v, 2))
        sfx = '%' if u == 'п.п.' else ''
        print(f"{r['метрика']} · {r['А']}: {val(r['А: значение'])}{sfx} (n = {r['А: n']}{', ' + r['А: интервал'] if r['А: интервал'] else ''}) · "
              f"{r['Б']}: {val(r['Б: значение'])}{sfx} (n = {r['Б: n']}{', ' + r['Б: интервал'] if r['Б: интервал'] else ''}) · "
              f"разница {chislo(r['разница'], 1, True)} {u} [{chislo(r['низ'], 1, True)}; {chislo(r['верх'], 1, True)}] · {r['тест']} · "
              f"p = {chislo(r['p'], 3)} · {r['поправка']}, p с поправкой = {chislo(r['p с поправкой'], 3)} · {r['эффект']}"
              f"{' · ' + r['выборка'] if r['выборка'] else ''} → {r['вердикт'].upper()}")
    print(f'\nТаблица — {out}. Слова «больше», «меньше», «одинаково» — только из столбца «вердикт».')


if __name__ == '__main__':
    main()
