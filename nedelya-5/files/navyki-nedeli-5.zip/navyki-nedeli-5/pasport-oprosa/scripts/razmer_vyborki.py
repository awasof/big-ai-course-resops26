#!/usr/bin/env python3
"""Сколько людей нужно на сравнение двух долей — и какую разницу увидит выборка, которая уже есть.

  python3 razmer_vyborki.py nuzhno --p1 0.40 --p2 0.33 [--alpha 0.05] [--moshchnost 0.8] [--dolya-gruppy 0.55]
      → людей в каждой группе; с --dolya-gruppy — сколько анкет всего, если группа — лишь часть опрошенных
        (например, сравниваем только пользующихся ИИ, а их около 55%)
  python3 razmer_vyborki.py uvidim --n 500 --p 0.40 [--alpha 0.05] [--moshchnost 0.8]
      → минимальная разница в п.п., которую увидит сравнение двух групп по n человек
  python3 razmer_vyborki.py pogreshnost --n 29 [--p 0.5]
      → половина ширины 95% интервала доли: «±N п.п.»

Формула — двусторонний тест для двух независимых долей (нормальное приближение):
  n = (z₁₋α/₂·√(2·p̄·q̄) + z₁₋β·√(p₁q₁ + p₂q₂))² / (p₁ − p₂)²
Ожидаемые доли берутся из брифа, прошлой волны или открытых данных; если их нет — это допущение, его надо записать.
"""
import argparse, math
ru = lambda x, d=1: f'{x:.{d}f}'.replace('.', ',').replace('-', '−')
from scipy import stats


def n_na_gruppu(p1, p2, alpha=0.05, power=0.8):
    za, zb = stats.norm.ppf(1 - alpha / 2), stats.norm.ppf(power)
    pb = (p1 + p2) / 2
    return math.ceil((za * math.sqrt(2 * pb * (1 - pb)) + zb * math.sqrt(p1 * (1 - p1) + p2 * (1 - p2))) ** 2 / (p1 - p2) ** 2)


def main():
    ap = argparse.ArgumentParser(); sp = ap.add_subparsers(dest='cmd', required=True)
    a1 = sp.add_parser('nuzhno'); a1.add_argument('--p1', type=float, required=True); a1.add_argument('--p2', type=float, required=True)
    a1.add_argument('--alpha', type=float, default=0.05); a1.add_argument('--moshchnost', type=float, default=0.8); a1.add_argument('--dolya-gruppy', type=float)
    a2 = sp.add_parser('uvidim'); a2.add_argument('--n', type=int, required=True); a2.add_argument('--p', type=float, required=True)
    a2.add_argument('--alpha', type=float, default=0.05); a2.add_argument('--moshchnost', type=float, default=0.8)
    a3 = sp.add_parser('pogreshnost'); a3.add_argument('--n', type=int, required=True); a3.add_argument('--p', type=float, default=0.5)
    a = ap.parse_args()
    if a.cmd == 'nuzhno':
        n = n_na_gruppu(a.p1, a.p2, a.alpha, a.moshchnost)
        print(f'Доли {a.p1:.0%} и {a.p2:.0%} (разница {"+" if a.p1 >= a.p2 else ""}{ru(100 * (a.p1 - a.p2))} п.п.), уровень {ru(a.alpha, 2)}, мощность {a.moshchnost:.0%}, двусторонний тест:')
        print(f'  нужно {n} человек в каждой группе, {2 * n} на сравнение')
        if a.dolya_gruppy:
            print(f'  если обе группы — {a.dolya_gruppy:.0%} опрошенных (например, только пользующиеся): всего анкет ≈ {math.ceil(2 * n / a.dolya_gruppy)}')
    elif a.cmd == 'uvidim':
        lo, hi = 0.0001, 0.5
        for _ in range(60):
            mid = (lo + hi) / 2
            if n_na_gruppu(a.p, max(1e-6, a.p - mid), a.alpha, a.moshchnost) > a.n:
                lo = mid
            else:
                hi = mid
        print(f'Две группы по {a.n} человек, доля около {a.p:.0%}: сравнение увидит разницу от {ru(100 * hi)} п.п. (мощность {a.moshchnost:.0%}, уровень {ru(a.alpha, 2)})')
    else:
        z = stats.norm.ppf(0.975)
        print(f'{a.n} человек, доля около {a.p:.0%}: погрешность ±{ru(100 * z * math.sqrt(a.p * (1 - a.p) / a.n))} п.п. (95%, нормальное приближение; для малых баз точнее интервал Уилсона)')


if __name__ == '__main__':
    main()
