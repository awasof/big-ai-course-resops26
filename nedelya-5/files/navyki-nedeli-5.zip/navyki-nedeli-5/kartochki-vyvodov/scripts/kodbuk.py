"""Кодбук из Markdown-таблицы: | Код | Название | Что входит | Что не входит | Примеры |.
Если в файле несколько кодбуков (## OA1 …, ## OA2 …), выбирается раздел по --vopros.

  load_codebook(path, vopros=None) → {код: название}
"""
import re, pathlib


def load_codebook(path, vopros=None):
    text = pathlib.Path(path).read_text(encoding='utf-8')
    if vopros:
        parts = re.split(r'\n(?=#{2,3} )', text)
        sel = [p for p in parts if re.match(rf'#{{2,3}}\s*{re.escape(vopros)}\b', p)]
        if not sel:
            raise SystemExit(f'В {path} нет раздела «## {vopros}»')
        text = sel[0]
    codes = {}
    for line in text.splitlines():
        if not line.strip().startswith('|'):
            continue
        c = [x.strip() for x in line.strip().strip('|').split('|')]
        if len(c) >= 2 and re.fullmatch(r'\d+', c[0]):
            codes[int(c[0])] = c[1]
    if not codes:
        raise SystemExit(f'В {path} не нашёл строк кодбука вида «| 1 | Название | … |»')
    return codes
