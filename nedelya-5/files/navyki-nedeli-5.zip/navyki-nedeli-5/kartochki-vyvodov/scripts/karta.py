"""Карта данных и выгрузка опроса: прочитать, развернуть, проверить.

Карта данных — таблица (Markdown, CSV или Excel) со столбцами:
  Колонка · Вопрос · Тип · Коды · Кому показан · Как считаем
Как в карте общей выгрузки «Нейрона»:
  | Q3_1…Q3_7, Q3_97, Q3_99 | Q3. Какими ИИ-сервисами… | несколько ответов | 1 ChatGPT · 2 Алиса AI · … | Q1 = 1 | % — от людей |

  Колонка      — одна колонка, список через запятую или диапазон «Q3_1…Q3_7» (можно «...»)
  Тип          — служебная · число · один ответ · несколько ответов · да или нет по каждому пункту ·
                 шкала · шкала 0–10 · открытый · текст · сплит
  Коды         — «1 Мужчина · 2 Женщина», «0–10», «коды как в Q3»
  Кому показан — «все», «Q1 = 1», «Q1 = 1 или 2», «M1 = 1 и S3 = 5», «Q1 ≠ 3»

  python3 karta.py карта.md выгрузка.csv     — разобрать карту и сверить её с выгрузкой
"""
import re, sys, json, pathlib
import pandas as pd

ALIAS = {
    'колонка': 'col', 'колонки': 'col', 'код колонки': 'col', 'переменная': 'col',
    'вопрос': 'q', 'текст': 'q', 'текст вопроса': 'q',
    'тип': 'type', 'коды': 'codes', 'коды и метки': 'codes', 'варианты': 'codes',
    'кому показан': 'base', 'база': 'base', 'логика показа': 'base',
    'как считаем': 'how', 'примечание': 'how',
}
TYPES = {
    'служебная': 'service', 'число': 'number', 'один ответ': 'single', 'несколько ответов': 'multi',
    'да или нет по каждому пункту': 'yesno', 'шкала': 'scale', 'шкала 0–10': 'scale010', 'шкала 0-10': 'scale010',
    'открытый': 'open', 'текст': 'text', 'сплит': 'split',
}


def _cells(line):
    s = line.strip()
    if s.startswith('|'):
        s = s[1:]
    if s.endswith('|'):
        s = s[:-1]
    return [c.strip() for c in s.split('|')]


def read_table(path):
    """Таблица карты из .md, .csv или .xlsx → DataFrame со столбцами col, q, type, codes, base, how."""
    p = pathlib.Path(path)
    if p.suffix.lower() == '.md':
        lines = [l for l in p.read_text(encoding='utf-8').splitlines() if l.strip().startswith('|')]
        head = None
        rows = []
        for l in lines:
            c = _cells(l)
            if head is None:
                if any(x.lower() in ALIAS for x in c):
                    head = c
                continue
            if set(''.join(c)) <= set('-: '):
                continue
            rows.append(c + [''] * (len(head) - len(c)))
        if head is None:
            raise SystemExit(f'{p.name}: не нашёл таблицу со столбцом «Колонка»')
        df = pd.DataFrame(rows, columns=head)
    elif p.suffix.lower() in ('.xlsx', '.xls'):
        df = pd.read_excel(p, dtype=str).fillna('')
    else:
        df = pd.read_csv(p, dtype=str).fillna('')
    df.columns = [ALIAS.get(str(c).strip().lower(), str(c).strip()) for c in df.columns]
    for c in ('col', 'q', 'type', 'codes', 'base', 'how'):
        if c not in df:
            df[c] = ''
    return df


def expand_cols(spec):
    """«Q3_1…Q3_7, Q3_97, Q3_99» → ['Q3_1', …, 'Q3_7', 'Q3_97', 'Q3_99']; «start_time, end_time» → два имени."""
    out = []
    for part in re.split(r'\s*,\s*', spec.strip()):
        m = re.match(r'^(.*?)(\d+)\s*(?:…|\.\.\.)\s*(.*?)(\d+)$', part)
        if m and m.group(1) == m.group(3):
            out += [f'{m.group(1)}{i}' for i in range(int(m.group(2)), int(m.group(4)) + 1)]
        elif part:
            out.append(part)
    return out


def parse_codes(s):
    """«1 Мужчина · 2 Женщина» → {1: 'Мужчина', 2: 'Женщина'}; «0–10» → {0: '0', …, 10: '10'}."""
    s = (s or '').strip()
    m = re.match(r'^(\d+)\s*[–-]\s*(\d+)$', s)
    if m:
        return {i: str(i) for i in range(int(m.group(1)), int(m.group(2)) + 1)}
    s = s.split(';')[0]
    out = {}
    for part in re.split(r'\s*·\s*', s):
        m = re.match(r'^(\d+)\s+(.+)$', part.strip())
        if m:
            out[int(m.group(1))] = m.group(2).strip()
    return out


def parse_base(s):
    """«Кому показан» → выражение для DataFrame.query или None (показан всем).
    «Q1 = 1» → «`Q1` == 1»; «Q1 = 1 или 2» → «`Q1` in [1, 2]»; «A = 1 и B = 5» → «(…) and (…)»; «Q1 ≠ 3» → «`Q1` != 3»."""
    s = (s or '').strip()
    if not s or s.lower() in ('все', 'всем', 'все респонденты'):
        return None
    parts = re.split(r'\s+и\s+', s)
    exprs = []
    for p in parts:
        m = re.match(r'^([A-Za-z_][\w]*)\s*(=|≠|!=)\s*(.+)$', p.strip())
        if not m:
            raise ValueError(f'не понимаю условие показа: «{s}»')
        col, op, vals = m.group(1), m.group(2), [v.strip() for v in re.split(r'\s+или\s+|\s*,\s*', m.group(3))]
        nums = [float(v) if '.' in v else int(v) for v in vals]
        if op == '=':
            exprs.append(f'`{col}` == {nums[0]}' if len(nums) == 1 else f'`{col}` in {nums}')
        else:
            exprs.append(f'`{col}` != {nums[0]}' if len(nums) == 1 else f'`{col}` not in {nums}')
    return ' and '.join(f'({e})' for e in exprs)


def load(path):
    """Карта данных → список вопросов: {cols, q, type, codes, base, how}. Мультивыбор — одна запись на вопрос."""
    df = read_table(path)
    items, by_q = [], {}
    for _, r in df.iterrows():
        if not str(r['col']).strip():
            continue
        t = TYPES.get(str(r['type']).strip().lower(), str(r['type']).strip().lower() or 'unknown')
        codes_s = str(r['codes'])
        ref = re.match(r'коды как в\s+(\S+)', codes_s.strip().lower())
        it = {'cols': expand_cols(str(r['col'])), 'q': str(r['q']).strip(), 'type': t,
              'codes': parse_codes(codes_s), 'codes_ref': ref.group(1).upper() if ref else None,
              'base_text': str(r['base']).strip(), 'base': parse_base(str(r['base'])), 'how': str(r['how']).strip()}
        m = re.match(r'^([A-Za-z]+\d*)\.', it['q'])
        it['id'] = m.group(1) if m else it['cols'][0]
        if it['id'] in by_q:                       # «Q3. Другое (впишите)» рядом с Q3 — по имени колонки
            it['id'] = it['cols'][0]
        items.append(it)
        by_q[it['id']] = it
    for it in items:
        if it['codes_ref'] and it['codes_ref'] in by_q:
            it['codes'] = dict(by_q[it['codes_ref']]['codes'])
    return items


def read_export(path, sheet=None):
    """Выгрузка: CSV или Excel. В Excel с двумя строками шапки (текст вопроса и код колонки) берётся строка с кодами."""
    p = pathlib.Path(path)
    if p.suffix.lower() in ('.xlsx', '.xls'):
        df = pd.read_excel(p, sheet_name=sheet or 0, header=0)
        if sum(str(c).startswith('Unnamed') for c in df.columns) > len(df.columns) / 3 or not any(re.match(r'^[A-Za-z_]\w*$', str(c)) for c in df.columns[:3]):
            df = pd.read_excel(p, sheet_name=sheet or 0, header=1)
        return df
    data = p.read_bytes()
    enc = 'utf-8-sig' if data.startswith(b'\xef\xbb\xbf') else 'utf-8'
    try:
        data.decode(enc)
    except UnicodeDecodeError:
        enc = 'cp1251'                              # выгрузки из старых систем и Excel под Windows
    first = data.split(b'\n', 1)[0]
    sep = ';' if first.count(b';') > first.count(b',') else ('\t' if first.count(b'\t') > first.count(b',') else ',')
    return pd.read_csv(p, sep=sep, encoding=enc, low_memory=False)


def shown(df, item):
    """Маска строк, которым вопрос показан по карте данных."""
    if not item['base']:
        return pd.Series(True, index=df.index)
    try:
        return df.eval(item['base']).fillna(False).astype(bool)
    except Exception:
        idx = df.query(item['base']).index
        return df.index.isin(idx)


def check(map_path, export_path):
    items = load(map_path)
    df = read_export(export_path)
    cols_map = [c for it in items for c in it['cols']]
    print(f'Карта: вопросов {len(items)}, колонок {len(cols_map)}')
    print(f'Выгрузка: строк {len(df)}, колонок {df.shape[1]}')
    miss = [c for c in cols_map if c not in df.columns]
    extra = [c for c in df.columns if c not in cols_map]
    print('Колонки карты, которых нет в выгрузке:', miss or 'нет')
    print('Колонки выгрузки, которых нет в карте:', extra or 'нет')
    for it in items:
        if it['base']:
            try:
                n = int(shown(df, it).sum())
                print(f"  {it['id']}: показан {n} строкам — {it['base_text']}")
            except Exception as e:
                print(f"  {it['id']}: условие показа не считается ({e})")
    return items, df


if __name__ == '__main__':
    if len(sys.argv) < 3:
        sys.exit(__doc__)
    check(sys.argv[1], sys.argv[2])
