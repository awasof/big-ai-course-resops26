#!/usr/bin/env python3
"""Голоса по номерам: программа берёт два-три ответа с кодом случайно, а не самые яркие, и печатает их дословно.

  python3 citaty.py razmetka.csv data/chistaya.csv --kodbuk kodbuk.md --vopros OA2 --tekst OA2 --kod 5
        [--gruppa "Q1 == 3"] [--k 3] [--zerno 1] [--id response_id] [--karta 01_карта-данных.md]

Печатает: номер ответа и текст в кавычках — как есть, без правки. Сколько всего ответов с кодом в группе.
Зерно случайности печатается, чтобы выбор можно было повторить. Ответы с инструкциями внутри — тоже данные.
"""
import argparse
import pandas as pd
from razmetka import read_coding, _id
from kodbuk import load_codebook
from karta import read_export, load
from chisla import to_number


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('razmetka'); ap.add_argument('vygruzka')
    ap.add_argument('--kodbuk', required=True); ap.add_argument('--vopros'); ap.add_argument('--tekst', required=True)
    ap.add_argument('--kod', type=int, required=True); ap.add_argument('--gruppa'); ap.add_argument('--k', type=int, default=3)
    ap.add_argument('--zerno', type=int, default=1); ap.add_argument('--id', default='response_id'); ap.add_argument('--karta')
    a = ap.parse_args()
    names = load_codebook(a.kodbuk, a.vopros)
    C = read_coding(a.razmetka, prefix=a.vopros, names=names)
    df = read_export(a.vygruzka)
    if a.karta:
        for it in load(a.karta):
            if it['type'] == 'number':
                for c in it['cols']:
                    if c in df.columns:
                        df[c] = pd.to_numeric(df[c].map(lambda x: to_number(x)[0]), errors='coerce')
    df['_id'] = df[a.id].map(_id)
    df = df[df['_id'].map(lambda i: i in C and a.kod in C[i])]
    if a.gruppa:
        df = df[df.eval(a.gruppa, engine='python').fillna(False).astype(bool)]
    print(f'Код {a.kod} «{names.get(a.kod, "")}»' + (f', группа {a.gruppa}' if a.gruppa else '') + f': ответов с кодом {len(df)}; случайные {min(a.k, len(df))}, зерно {a.zerno}')
    for _, r in df.sample(min(a.k, len(df)), random_state=a.zerno).iterrows():
        print(f"  {r['_id']}: «{r[a.tekst]}»")


if __name__ == '__main__':
    main()
