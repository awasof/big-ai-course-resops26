"""Разметка открытых ответов: прочитать в любом виде и привести к одному.

Виды файла разметки:
  широкий  — response_id, …, OA2_1, OA2_2, …, OA2_98 (1 — код есть, 0 — нет)
  длинный  — id, codes  (codes: «3;7», «[3, 7]» или «3, 7»), можно ещё quote
  JSON     — [{"id": "10007", "codes": [9], "quote": "…"}] — ответ модели на пачку

  read_coding(path, prefix=None) → {id (str): frozenset(кодов)}
  «файл.csv:OA2_codes» — взять коды из названной колонки (длинный вид)
"""
import re, json, pathlib
import pandas as pd


def _codes(v, names=None):
    """Коды из ячейки: [3, 7], «3;7», «3, 7» — или названия кодов через «;», если передан кодбук names {код: название}."""
    if isinstance(v, (list, tuple, set)):
        return frozenset(int(x) for x in v)
    if v is None or (isinstance(v, float) and v != v) or str(v).strip() == '':
        return frozenset()
    if names and not re.search(r'\d', str(v)):
        back = {n.strip().lower(): k for k, n in names.items()}
        out = set()
        for part in str(v).split(';'):
            k = back.get(part.strip().lower())
            if k is None:
                raise SystemExit(f'Название кода «{part.strip()}» не найдено в кодбуке')
            out.add(k)
        return frozenset(out)
    return frozenset(int(x) for x in re.findall(r'\d+', str(v)))


def _id(x):
    s = str(x).strip()
    return s[:-2] if s.endswith('.0') else s


def read_coding(path, prefix=None, idcol=None, names=None):
    col = None
    if ':' in str(path) and not pathlib.Path(path).exists():
        path, col = str(path).rsplit(':', 1)
    p = pathlib.Path(path)
    if p.suffix.lower() == '.json':
        data = json.loads(p.read_text(encoding='utf-8'))
        if isinstance(data, dict):
            return {_id(k): _codes(v) for k, v in data.items()}
        ids = [_id(r['id']) for r in data]
        if len(ids) != len(set(ids)):
            raise SystemExit(f'{p.name}: повторяющиеся номера ответов в разметке')
        return {_id(r['id']): _codes(r.get('codes')) for r in data}
    df = pd.read_excel(p) if p.suffix.lower() in ('.xlsx', '.xls') else pd.read_csv(p, dtype=str)
    idc = idcol or next((c for c in df.columns if c.lower() in ('id', 'response_id', 'номер', 'номер ответа')), df.columns[0])
    ids = df[idc].map(_id)
    if ids.duplicated().any():
        raise SystemExit(f'{p.name}: повторяющиеся номера ответов в разметке')
    if col:
        return {_id(r[idc]): _codes(r[col], names) for _, r in df.iterrows()}
    if prefix is None:
        cand = [c for c in df.columns if re.fullmatch(r'[A-Za-z]+\d*_\d+', c)]
        prefix = cand[0].rsplit('_', 1)[0] if cand else None
    wide = [c for c in df.columns if prefix and re.fullmatch(rf'{re.escape(prefix)}_\d+', c)]
    if wide:
        out = {}
        for _, r in df.iterrows():
            out[_id(r[idc])] = frozenset(int(c.rsplit('_', 1)[1]) for c in wide if str(r[c]).strip() in ('1', '1.0'))
        return out
    cc = next((c for c in df.columns if c.lower() in ('codes', 'коды', 'kody', 'код')), None)
    if cc is None:
        raise SystemExit(f'{p.name}: не нашёл ни колонок {prefix}_N, ни колонки codes')
    return {_id(r[idc]): _codes(r[cc], names) for _, r in df.iterrows()}
