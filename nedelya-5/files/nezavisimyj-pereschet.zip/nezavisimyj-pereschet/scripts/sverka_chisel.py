#!/usr/bin/env python3
"""Сверка двух счётов: что посчитала проверяющая сессия и что стоит в таблицах или отчёте.

  python3 sverka_chisel.py sverka.csv [--dopusk 0.1]

sverka.csv — колонки ровно с такими названиями:
  chto,baza,pereschet,v_otchete,dopusk
  Пользуются ИИ,все после чистки (3000),57.47,57.5,
  Платят (M1 = 1 или 2),пользующиеся (1724),13.05,13.1,
  Через посредника (M3_2),платят сами (186),48.39,3.0,

baza — ваша база по паспорту; база отчёта, если она названа, — в колонку chto или в описание расхождения.
dopusk — в тех же единицах (п.п.); пусто — по точности отчёта: «57,5» — ±0,05, «31» — ±0,5, но не меньше --dopusk (0,1).
Печатает «сошлось» или «НЕ СОШЛОСЬ» по каждой строке. Не сошлось — не подгоняйте: ищите, где разошлись
база, правило чистки, перекодировка или от кого процент. Код выхода 2 при расхождениях.
"""
import sys, argparse
import pandas as pd


def main():
    ap = argparse.ArgumentParser(); ap.add_argument('fajl'); ap.add_argument('--dopusk', type=float, default=0.1)
    a = ap.parse_args()
    S = pd.read_csv(a.fajl, dtype=str).fillna('')
    f = lambda x: float(str(x).replace('−', '-').replace(',', '.').replace('%', '').strip())
    bad = 0
    for _, r in S.iterrows():
        x, y = f(r['pereschet']), f(r['v_otchete'])
        raw_y = str(r['v_otchete']).replace(',', '.').strip()
        dec = len(raw_y.split('.')[1]) if '.' in raw_y else 0
        d = float(r['dopusk'].replace(',', '.')) if r.get('dopusk') else max(a.dopusk, 0.5 * 10 ** (-dec))
        ok = abs(x - y) <= d + 1e-9
        bad += not ok
        print(f"{'сошлось    ' if ok else 'НЕ СОШЛОСЬ '} {r['chto']} ({r.get('baza', '')}): пересчёт {x:g}, в отчёте {y:g}, разница {x - y:+.2f}")
    print(f'\nСтрок {len(S)}, не сошлось {bad}.' + (' Остановитесь: найдите, где разошлись база или правило, и опишите это.' if bad else ''))
    sys.exit(2 if bad else 0)


if __name__ == '__main__':
    main()
