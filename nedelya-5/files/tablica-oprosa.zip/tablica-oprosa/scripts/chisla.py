"""Числа, записанные текстом: «45 лет», «1 500 руб», «2к», «~1000», «499р».

  to_number(x)  → (число или None, как прочитано: 'число' | 'текст → число' | 'не число')
"""
import re
import math


def to_number(x):
    if x is None:
        return None, 'пусто'
    if isinstance(x, (int, float)):
        return (None, 'пусто') if (isinstance(x, float) and math.isnan(x)) else (float(x), 'число')
    s = str(x).strip().lower().replace(' ', ' ')
    if not s or s in ('nan', 'none'):
        return None, 'пусто'
    try:
        return float(s.replace(',', '.')), 'число'
    except ValueError:
        pass
    s = re.sub(r'^(?:~|≈|около|примерно|где-то|где то|до)\s*', '', s)
    m = re.match(r'^(\d[\d\s]*(?:[.,]\d+)?)\s*(к|тыс\.?|тысяч[аи]?)?\s*(руб\.?|р\.?|₽|лет|год[а]?|г\.?|л\.?)?\s*$', s)
    if m:
        v = float(m.group(1).replace(' ', '').replace(',', '.'))
        if m.group(2):
            v *= 1000
        return v, 'текст → число'
    return None, 'не число'
