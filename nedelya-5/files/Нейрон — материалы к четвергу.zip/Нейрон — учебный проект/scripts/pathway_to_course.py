#!/usr/bin/env python3
"""Convert a native Pathway CSV into the analytic columns required by the course skills."""
from argparse import ArgumentParser
import csv
import json
from pathlib import Path
import re


def convert(source, mapping_path, data_map, output):
    mapping = json.loads(mapping_path.read_text(encoding='utf-8'))
    native = mapping['csv_export']
    codes = {q['question']: {v['label']: v['code'] for v in q['options']}
             for q in mapping['blocks']}
    question_by_id = {q['pathwayBlockId']: q['question'] for q in mapping['blocks']}
    for q in mapping['blocks']:
        if q['pipingSource']:
            inherited = codes[question_by_id[q['pipingSource']]]
            codes[q['question']].update({label: code for label, code in inherited.items() if code != 99})
    columns = [line.split('|')[1].strip()
               for line in data_map.read_text(encoding='utf-8').splitlines()
               if re.match(r'^\| (?!Колонка)', line)]
    system = native['system_columns_1_based']
    expect_header = native['headers']
    decode_bool = {'TRUE': 1, 'FALSE': 0, '': ''}
    with source.open(encoding='utf-8', newline='') as f:
        reader = csv.reader(f, delimiter=native['delimiter'], quotechar=native['quotechar'], strict=True)
        header = next(reader)
        if header != expect_header:
            raise SystemExit('Заголовки выгрузки отличаются от карты Pathway')
        output.parent.mkdir(parents=True, exist_ok=True)
        with output.open('x', encoding='utf-8', newline='') as o:
            writer = csv.DictWriter(o, fieldnames=columns, lineterminator='\n')
            writer.writeheader()
            for number, row in enumerate(reader, 2):
                if len(row) != len(header):
                    raise ValueError(f'Строка {number}: неверное число колонок')
                record = {
                    'response_id': row[system['id']-1],
                    'duration_sec': row[system['duration_sec']-1],
                    'status': row[system['status']-1],
                    'show_q22': 0,
                }
                try:
                    for q, spec in native['question_columns_1_based'].items():
                        if 'options' in spec:
                            for option in spec['options']:
                                record[f'{q}_{option["code"]}'] = decode_bool[row[option['column']-1]]
                        elif 'answer_column' in spec:
                            value = row[spec['answer_column']-1]
                            if row[spec['other_answers_column']-1]:
                                raise ValueError(f'У {q} есть текст в дополнительной колонке')
                            record[q] = codes[q][value] if value else ''
                        else:
                            record[q] = row[spec['text_column']-1]
                except KeyError as e:
                    raise ValueError(f'Строка {number}: неизвестное значение {e}') from e
                record['show_q20'] = int(record['Q5'] in (2, 3)
                                          or (record['Q5'] == 1 and record['Q8'] == 2))
                writer.writerow(record)


def main():
    project = Path(__file__).resolve().parents[1]
    ap = ArgumentParser(description=__doc__)
    ap.add_argument('input', type=Path)
    ap.add_argument('output', type=Path)
    ap.add_argument('--mapping', type=Path, default=project/'поля-Pathway.json')
    ap.add_argument('--data-map', type=Path, default=project/'karta-dannyh.md')
    args = ap.parse_args()
    if args.input.resolve() == args.output.resolve():
        ap.error('Укажите новый путь для выходного файла')
    convert(args.input, args.mapping, args.data_map, args.output)


if __name__ == '__main__':
    main()
