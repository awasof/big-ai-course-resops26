# /// script
# requires-python = ">=3.10"
# dependencies = [
#   "faster-whisper>=1.1",
#   "av<19",
#   "numpy",
#   "sounddevice; sys_platform != 'darwin'",
#   "pyobjc-framework-ScreenCaptureKit; sys_platform == 'darwin'",
#   "pyobjc-framework-CoreMedia; sys_platform == 'darwin'",
#   "pyobjc-framework-AVFoundation; sys_platform == 'darwin'",
#   "pyobjc-framework-libdispatch; sys_platform == 'darwin'",
#   "pyinstaller; sys_platform == 'darwin'",
# ]
# ///
"""Прогрев перед занятием: скачивает все пакеты и модели tiny и base, чтобы на занятии ничего не качалось.

Запуск из этой папки: uv run warm-up.py
Первый раз занимает несколько минут: скачивается около полугигабайта (пакеты) и 216 МБ (две модели). Повторный запуск — секунды.

По желанию — большая модель medium (1,53 ГБ): uv run warm-up.py medium
Скачает tiny, base и medium. Нужно ещё около 2 ГБ свободного места.
"""

import sys
import time

from faster_whisper import WhisperModel

names = ["tiny", "base"] + (["medium"] if "medium" in sys.argv[1:] else [])
for name in names:
    started = time.time()
    print(f"Скачиваю модель «{name}»…", flush=True)
    WhisperModel(name, device="cpu", compute_type="int8")
    print(f"  готово за {time.time() - started:.0f} с", flush=True)
if "medium" in names:
    print("Всё готово: пакеты и модели tiny, base и medium на этом компьютере.")
else:
    print("Всё готово: пакеты и обе модели на этом компьютере.")
