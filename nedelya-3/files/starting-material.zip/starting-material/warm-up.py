# /// script
# requires-python = ">=3.10"
# dependencies = [
#   "faster-whisper>=1.1",
#   "av<19",
#   "numpy",
#   "sounddevice; sys_platform != 'darwin'",
#   "pyobjc-framework-ScreenCaptureKit; sys_platform == 'darwin'",
#   "pyobjc-framework-CoreMedia; sys_platform == 'darwin'",
#   "pyobjc-framework-AVFoundation; sys_platform == 'darwin'",
#   "pyobjc-framework-libdispatch; sys_platform == 'darwin'",
#   "pyinstaller; sys_platform == 'darwin'",
# ]
# ///
"""Прогрев перед занятием: скачивает все пакеты и модели tiny и base, чтобы на занятии ничего не качалось.

Запуск из этой папки: uv run warm-up.py
Первый раз занимает несколько минут: скачивается около полугигабайта (пакеты) и 216 МБ (две модели). Повторный запуск — секунды.
"""

import time

from faster_whisper import WhisperModel

for name in ("tiny", "base"):
    started = time.time()
    print(f"Скачиваю модель «{name}»…", flush=True)
    WhisperModel(name, device="cpu", compute_type="int8")
    print(f"  готово за {time.time() - started:.0f} с", flush=True)
print("Всё готово: пакеты и обе модели на этом компьютере.")
